<?php
$updatefiles = "UpdateFiles.bat";
exec("start $updatefiles");
echo "Finished";
header('Location: ../index.htm');
exit;
?>