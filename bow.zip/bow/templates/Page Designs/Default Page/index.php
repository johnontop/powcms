 
<?php 
ini_set('display_errors', '0');

echo $_POST['submit'];

if($_POST['submit']) {

  $file = 'index.html'; 
  $newfile = '../../../index.htm';
  if(!copy($file,$newfile))
   {echo "Dailed to copy ". $file."<br>";}
   else
    {echo
     "Copied ".$file." into ".$newfile."<br>";
    } 
    
  $file = 'default-mod.css'; 
  $newfile = '../../../theme/default-mod.css';
  if(!copy($file,$newfile))
   {echo "Dailed to copy ". $file."<br>";}
   else
    {echo
     "Copied ".$file." into ".$newfile."<br>";
    }     

$srcPath = './theme/';
$destPath = '../../../theme/';  
$srcDir = opendir($srcPath);
while($readFile = readdir($srcDir))
{
    if($readFile != '.' && $readFile != '..')
    {
        /* this check doesn't really make sense to me,
           you might want !file_exists($destPath . $readFile) */
        if (!file_exists($readFile)) 
        {
            if(copy($srcPath . $readFile, $destPath . $readFile))
            {
                echo "Copy file: ".$readFile."<br>" ;
            }
            else
            {
                echo "Canot Copy file";
            }
        }
    }
}
closedir($srcDir);

header('Location: http://localhost/index.htm');

} 
?>

 <!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Title of the document</title>
</head>
<body>  
<div class="container">
<div style="absolute:relative; left:20; top:80; z-index:1000;">
<form id="myForm" class="" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
<input id="saveForm" name="submit" type="submit" value="Apply Page Design" />
</form>	

<?php
$get_file  = file_get_contents("index.html");
echo $get_file ;
?>

</div>
</body>
</html>




