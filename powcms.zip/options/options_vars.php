<?php 

$options_base_path = "https://raw.githubusercontent.com/johnontop/powcms/master/" ;
$options_folder =  "optional/" ;
$options_content = "options.htm";
$options_dl_path =  $options_base_path . $options_folder ; 
$options_info = $options_base_path . $options_folder . $options_content ;
$dl_file = array("test.zip");  // separate zip files with a comma
//$dl_file = array("test.zip","test1.zip","test2.zip");  // separate zip files with a comma
$show_options = file_get_contents('https://raw.githubusercontent.com/johnontop/powcms/master/optional/options.htm');

?>