<br />
<b>Notice</b>:  Undefined index: bootstrap_css_path in <b>/jet/app/www/default/dev9/app/enviameinfo2/_lib/libraries/sys/tinymce4.5.5/tinymce/plugins/bootstrap/conf/conf.php</b> on line <b>21</b><br />
<br />
<b>Notice</b>:  Undefined index: language in <b>/jet/app/www/default/dev9/app/enviameinfo2/_lib/libraries/sys/tinymce4.5.5/tinymce/plugins/bootstrap/conf/conf.php</b> on line <b>33</b><br />
<br />
<b>Notice</b>:  Undefined index: images_path in <b>/jet/app/www/default/dev9/app/enviameinfo2/_lib/libraries/sys/tinymce4.5.5/tinymce/plugins/bootstrap/bootstrap-image.php</b> on line <b>6</b><br />
<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="css/plugin.min.css">
    <link href='jquery-file-tree/jqueryFileTree.css' rel='stylesheet' type='text/css'>
    <link href="prism/prism.min.css" type="text/css" rel="stylesheet" />
</head>
<body><div class="container"><p>&nbsp;</p><p class="alert alert-danger">Your images dir is not authorized.</p><p class="text-center">Please create an empty file named <strong><i>secure.php</i></strong> and save it into <strong><i></i></strong> to allow access.</p></div><body>