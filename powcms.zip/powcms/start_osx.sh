#!/bin/bash
python -m SimpleHTTPServer 8080 ;

php -S localhost:8080 ;

start.htm ;

exit;