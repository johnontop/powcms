<?php
ini_set('display_errors', '0');

// Makes the module translatable.
$root = $_COOKIE['root']; 
include  $root.'pow-config.php' ;
include $root . 'theme/translation.'.$lang_code.'.php';
// Get download page and files variables.
include 'options_vars.php';

if (!isset($_GET['action'])){ 
  echo "<h4>Options will download zip files from the specified web site and install the zips.<h4/>";
}  else {
  echo "GET is set to - files!<br />";  
  $updatefiles = "pow-download.bat";
  exec("start /MIN $updatefiles");
  echo "Finished Backup";
  
    function collect_file($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch, CURLOPT_REFERER, $options_base_path );
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $result = curl_exec($ch);
        curl_close($ch);
        return($result);
    }

    function write_to_file($text,$new_filename){
        $fp = fopen($new_filename, 'w');
        fwrite($fp, $text);
        fclose($fp);
    }

  // start loop here        
    foreach ($dl_file as $value) {
    $new_file_name = "downloads/".$value ;
    write_to_file(collect_file($options_dl_path.$value),$new_file_name);

  // Extract downloaded zip
    $zip_obj = new ZipArchive;
    $zip_obj->open($new_file_name);
    $zipChunks = explode(".", $value);
    $folder = $zipChunks[0] ;
    mkdir("../".$folder);
    $zip_obj->extractTo('../'.$folder);    
    
    echo "<br>".$value;
    usleep(500000);
    } 

    // Get online version and save to downloads    
    $online_version = file_get_contents('https://raw.githubusercontent.com/johnontop/powcms/master/optional/option-version.txt');
    $option_version = 'downloads/option-version.txt';
    $fp = fopen($option_version, 'w');
    fwrite($fp, $online_version);
    fclose($fp);     
    
    $message = "Manually copy updated files in /options/downloads/ folder to your root folder" ;
    setcookie('message', $message , time()+60 );    
    header('Location: index.htm');
    //header('Location: ../pow-update.php?action=update');
exit;  
}

//$online_history = file_get_contents('https://powcms.000webhostapp.com/res/history.htm');
//$online_history = file_get_contents('https://raw.githubusercontent.com/johnontop/powcms/master/system/history.htm');
  $dl_filename = 'downloads/options.htm';
  $fp = fopen($dl_filename, 'w');
  fwrite($fp, $show_options);
  fclose($fp);

echo"<h4>Detecting versions</h4>" ;
$local_version = file_get_contents('downloads/option-version.txt');
echo "Local version date: <b>" ;
echo $local_version .'</b><br>';
//$downloaded_version = file_get_contents('downloads/option-version.txt');
//echo "Download version date: <b>" ;
//echo $downloaded_version .'</b><br>';   
//$online_version = file_get_contents('https://powcms.000webhostapp.com/pow-version.txt');
$online_version = file_get_contents('https://raw.githubusercontent.com/johnontop/powcms/master/optional/option-version.txt');
echo "Online version date: <b>" ;
echo $online_version .'</b><br><br>';
if ($local_version == $online_version){
echo "<strong>You have the latest updates installed.<br>Run System Update to view the updates.</strong><br>" ;
} else   {
$message = "There are a updated option versions for download - consider updating option files" ;
if(isset($_COOKIE['message'])) {
$message = $_COOKIE['message'] ;
} 
echo "<strong>" .$message. "</strong><br>" ;
} 
if ($local_version != $online_version){   ?>
<h4 id="finalMessage"></h4>
<progress id="progressBar" value="0" max="100" style="width: 300px;"></progress> <span id="status"></span> <br /> 
<a class="button" href="options.php?action=1" onclick="start(0);"> Download and Update Folders and Pages </a>
<p><br />
Option Updater will download the latest option zip files from the online options folder.<br /> The files will be saved to the folder /options/downloads/ then unzipped to view. <br>
Read latest version news below.</p>
<br /> <iframe src="<?php echo $dl_filename ;?>" width="100%" height="350px"></iframe> <?php
}
?>
<script>
function start(al) {
 // document.getElementById('progressBar').style.display='block';
  var bar = document.getElementById('progressBar');
  var status = document.getElementById('status');
  status.innerHTML = al+"%";
  var finalMessage = document.getElementById('finalMessage');
  finalMessage.innerHTML = "Backup files and download updates";
  bar.value = al;
  al++;
    var sim = setTimeout("start("+al+")",80);
    if(al == 100){
      status.innerHTML = "100%";
      bar.value = 100;
      clearTimeout(sim);
      var finalMessage = document.getElementById('finalMessage');
      finalMessage.innerHTML = "Download of updates is complete";
        }
    }
</script>