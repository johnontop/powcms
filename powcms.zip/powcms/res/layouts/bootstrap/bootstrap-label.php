<br />
<b>Notice</b>:  Undefined index: bootstrap_css_path in <b>/jet/app/www/default/dev9/app/enviameinfo2/_lib/libraries/sys/tinymce4.5.5/tinymce/plugins/bootstrap/conf/conf.php</b> on line <b>21</b><br />
<br />
<b>Notice</b>:  Undefined index: language in <b>/jet/app/www/default/dev9/app/enviameinfo2/_lib/libraries/sys/tinymce4.5.5/tinymce/plugins/bootstrap/conf/conf.php</b> on line <b>33</b><br />
<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="css/plugin.min.css">
    <link href="prism/prism.min.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <div class="container">
        <div class="row margin-bottom-md">
            <div class="choice-title">
                <span>Label style</span>
            </div>
            <div class="col-md-12">
                <div class="text-center">
                    <div class="choice selector select-label-style">
                        <span class="label label-default" data-attr="label-default">default</span>
                    </div>
                    <div class="choice selector select-label-style">
                        <span class="label label-primary" data-attr="label-primary">primary</span>
                    </div>
                    <div class="choice selector select-label-style">
                        <span class="label label-success" data-attr="label-success">success</span>
                    </div>
                    <div class="choice selector select-label-style">
                        <span class="label label-info" data-attr="label-info">info</span>
                    </div>
                    <div class="choice selector select-label-style">
                        <span class="label label-warning" data-attr="label-warning">warning</span>
                    </div>
                    <div class="choice selector select-label-style">
                        <span class="label label-danger" data-attr="label-danger">danger</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row margin-bottom-md">
            <div class="choice-title">
                <span>Label text</span>
            </div>
                <p></p>
                <div class="col-sm-6 col-sm-offset-3 form-inline">
                        <div class="form-group">
                        <label for="label-text">Your text : </label>
                            <input name="label-text" class="form-control select-text" type="text" value="New">
                        </div>
                </div>
        </div>
        <div class="row" id="preview">
            <div id="preview-title" class="margin-bottom-md">
                <span class="label-primary">Preview</span>
            </div>
            <div class="col-sm-12 margin-bottom-md text-center" id="test-wrapper">
                <span class="label label-primary">New</span>            </div>
        </div>
        <div class="row">
            <div id="code-title">
                <a href="#" id="code-slide-link">Code <i class="glyphicon glyphicon-arrow-up"></i></a>
            </div>
            <div class="col-sm-12" id="code-wrapper">
                <pre></pre>
            </div>
        </div>
    </div>
<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/utils.min.js"></script>
<script type="text/javascript" src="js/jquery.htmlClean.min.js"></script>
<script type="text/javascript" src="prism/prism.min.js"></script>
<script type="text/javascript">
    var newLabel  = '1';
    var labelStyle  = 'label-primary';
    var labelText  = 'New';
    var labelCode  = '<span class="label label-primary">New</span>';
    $.noConflict();
    jQuery(document).ready(function ($) {

        makeResponsive();
        getBootstrapStyles();

        /* if newLabel === false, we get code from tinymce */

        if (!newLabel) {
            labelCode = getCode('.label.active');
            var find = new Array(/\s?data-mce-[a-z]+="[^"]+"/g, / active/);
            var replace = new Array('', '');

            for (var i = find.length - 1; i >= 0; i--) {
                labelCode = labelCode.replace(find[i], replace[i]);
            }
            $('#test-wrapper').html(labelCode);
            labelText = $('#test-wrapper .label').html();

            /* get style from tinymce */

            $('.select-label-style span').each(function (index, el) {
                var dataAttr = $(this).attr('data-attr');
                if ($('#test-wrapper .label').hasClass(dataAttr)) {
                    labelStyle = dataAttr;
                }
            });

            /* input text value */

            $('.select-text').val(labelText);
        }

        /* label style */

        $('.selector.select-label-style').each(function (event, element) {

            /* set style on load */

            if ($(element).find('.label').attr('data-attr') == labelStyle) {
                $(element).addClass('active');
            }

            $(element).on('click', function (event) {
                $('.selector.select-label-style').removeClass('active');
                $(this).addClass('active');
                $('#test-wrapper').find('.label').removeClass(labelStyle);
                labelStyle = $(this).find('.label').attr('data-attr');
                $('#test-wrapper').find('.label').addClass(labelStyle);
                updateCode();
            });
        });

        updateCode();

        /* text input */

        $('input[name="label-text"]').on('click, focus', function () {
            $(this).on('keyup', function () {
                changeText(this);
            });
        });

        function changeText(input)
        {
            var value = $(input).prop('value');
            $('#test-wrapper').find('.label').html(value);
            updateCode();
        }
    });
</script>
</body>
</html>
