tinymce.addI18n('tr',{
	'YouTube Title' : "YouTube Videosu Ekle",
	'Youtube URL'	: 'Youtube Linki',
	'Youtube ID'    : 'Link Formatı : http://youtu.be/xxxxxxxx yada http://www.youtube.com/watch?v=xxxxxxxx gibi',
	'width'			: 'Genişlik',
	'height'		: 'Yükseklik',
	'autoplay'		: 'Autoplay',
	'Related video' : 'İlgili video',
	'HD video'      : 'HD Olarak İzle'
});
