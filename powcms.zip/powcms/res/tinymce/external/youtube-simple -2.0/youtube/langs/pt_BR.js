tinymce.addI18n('pt_BR',{
	'YouTube Title' : "Inserir um vídeo do Youtube",
	'Youtube URL'	: 'URL do Youtube',
	'Youtube ID'    : 'Formato do link : http://youtu.be/xxxxxxxx or http://www.youtube.com/watch?v=xxxxxxxx',
	'width'			: 'Largura',
	'height'		: 'Altura',
	'autoplay'		: 'Tocar automaticamente',
	'Related video' : 'Vídeos relacionados',
	'HD video'      : 'Assistir em HD'
});