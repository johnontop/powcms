<!DOCTYPE html>
<html>
<head><!-- http://mesdomaines.nu/eendracht/rte/tinymce_explanations.html -->
<meta http-equiv="Content-Type" content="text/html; charset="utf-8" >

<title>File TinyMCE</title>

<!-- This is the line that does almost everything. We can find it at http://www.tinymce.com/index.php  -->
<script src="http://localhost/res/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
tinymce.init({
        selector: "textarea",
         height : "430px",
        plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "newdocument fullpage | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media code | insertdatetime preview | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",

        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],

        templates: [
                {title: 'Test template 1', content: 'Test 1'},
                {title: 'Test template 2', content: 'Test 2'}
        ]
});
</script>

</head>

<body >
<!-- Thanks to http://www.dreamincode.net/forums/topic/9866-textarea-editor for the php part -->

<?php
//$file = "tinymce_save";
$load_file = $_POST['load_file'];  // Added
$save_file = $_POST['save_file'];
$file_name = $_POST['file_name'];   
$savecontent = $_POST['savecontent'];

echo $filePath = realpath($_FILES[$load_file]["tmp_name"])."<br>" ;
echo "realpath: ".realpath($load_file)."<br>" ;
echo "basename: ". basename($_FILES["load_file"]["name"])."<br>" ;
echo "Path: ".$filePath."<br>" ;
echo "Load: ".$load_file."<br>" ;
echo "Save: ".$save_file ;
?>

<?php
if($load_file) {
$loadcontent = $load_file;
echo $loadcontent;
//$loadcontent = $file.".htm";
if (!is_writable($loadcontent))
echo 'error';
}

if($save_file) {
$loadcontent = $file_name; // added for test
$savecontent = stripslashes($savecontent);
$fp = @fopen($loadcontent, "w");
if ($fp) {
//echo 'File Saved';
$status = 'File Saved';
fwrite($fp, $savecontent);
fclose($fp);
}
}
$fp = @fopen($loadcontent, "r");
$loadcontent = fread($fp, filesize($loadcontent));
$loadcontent = htmlspecialchars($loadcontent);
fclose($fp);
?>

<form action="<?=$_SERVER['PHP_SELF']?>"  method="post">
<div style="position: relative; width:800px; left: 50px; top: 20px; right: 20px;">
<input type="submit" value="Load">
<input type="file" name="load_file" >
<input type="text" name="file_name" value="<?php echo $load_file ;?>" >
</div>
</form>

<form style="position: relative; width:800px; left: 50px; top: 20px; right: 20px;" enctype="multipart/form-data" method="post" action="<?=$_SERVER['PHP_SELF']?>">
<textarea  name="savecontent" id="savecontent" >
<?=$loadcontent?>
</textarea>

<input type="submit" name="save_file" value="Save" style="position: absolute; top:2px; right: 2px">  
<div style="position: absolute; top:2px; right: 80px"><?php echo $status ;?></div>
<input type="hidden" name="file_name" value="<?php echo $load_file ;?>">
</form>

<script>
function size_it()
{
//Specifying the height of the field where the edits are done. You may have to alter the pixel-value (method: trial and error)
document.getElementById('savecontent').style.height=window.innerHeight-150+'px'
}
size_it()
</script>

</body>
</html> 