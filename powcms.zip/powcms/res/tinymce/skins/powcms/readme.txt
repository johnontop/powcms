This skin for POWCMS was made in sept-dec 2017

Is made with TinyMCE skin editor, found at 
http://skin.tinymce.com/

The sprite that replaces TinyMCE fonts comes from Polly Shaws "LightGray No Fonts skin" at
https://bitbucket.org/pollyshaw1/tinymce-4-lightgray-no-fonts-skin

Icon used are from famfamfams silk icons that are used by many other skins.
http://www.famfamfam.com/lab/icons/silk/

Sprites from some other skins can be found in the img folder.

