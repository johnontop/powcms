﻿    VARS = {};
    VARS.title = "Credits";
    VARS.name = "Credits";
    VARS.file_name = "licence.htm";
    VARS.data = "page-credits";
    VARS.category = "Sysinfo";
    VARS.date = "2017-09-11 12:17";
    VARS.image = "";
    VARS.tags = "Credits";
    VARS.description = "The POW CMS system would not exist if it wherent for these good coders. They deserve all credits for making it possible to create this CMS.";
                
        $.ajax({            
            url : "licence.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});             
            