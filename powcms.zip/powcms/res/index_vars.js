﻿    VARS = {};
    VARS.name = "Resources Info";
    VARS.file_name = "resources.htm";
    VARS.data = "page-res";
    VARS.category = "System";
    VARS.date = "";
    VARS.image = "theme/header-image.png";
    VARS.tags = "Bootstrap jQuery TinyMCE  Tipue Search";
    VARS.description = "The resources for Bootstrap, TinyMCE jQuery, Tipue Search Awesome Fonts and more files are stored in the res folder.";
                
        $.ajax({            
            url : "resources.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=theme/header-image.png>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});             
            