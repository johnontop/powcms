 VARS.system_title = "Portable Offline Web CMS";
 VARS.system_tagline = "Rocks the world!";
 VARS.system_image = "/theme/header-image.png";
 VARS.copyright = "Portable Offline Web CMS - 2017";
 VARS.lang_code = "en";
 VARS.language = "English";
 VARS.system_version = "0.5"; 
 
VARS.start = "Start Page";       // side-pages.htm menu 
 VARS.previous = "Previous Page";  // side-pages.htm menu
 VARS.next = "Next Page";          // side-pages.htm menu
 
 VARS.page_top = "Page Top!";   // main page foot
 
 VARS.title_status = "Title";       // status
 VARS.page_status = "Page";         // status
 VARS.data_status = "Data ID";      // status
 VARS.category_status = "Category"; // status
 VARS.edit = "Edit Page";           // status
 
 VARS.pages_side = "Pages";    // side menu
 VARS.links_side = "Links";    // side menu
 
 VARS.root = "Start";          // top menu
 VARS.search = "Search";       // top menu
 VARS.pages = "Pages";         // top menu
 VARS.index = "Index";         // top menu
 VARS.content = "Content";     // top menu 
 VARS.templates = "Templates"; // top menu
 VARS.sysinfo = "System Info"; // top menu
 VARS.back = "Back";           // top menu
 

 
 VARS.version_history = "Version History";              
 VARS.licenses = "Licenses";