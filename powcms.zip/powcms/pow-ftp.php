<?php
//http://stackoverflow.com/questions/13158476/php-upload-multiple-files-via-ftp
//http://www.w3bees.com/2013/02/multiple-file-upload-with-php.html
require ('dbc.php');
$title = 'Upload HTML file';

// Start output buffering:
ob_start();
// Initialize a session:
session_start();
ini_set('display_errors', '0');

$local_path = $root ."/pages/";
  
// FTP access parameters
$host = '';
$usr = '';
$pwd = '';
 
// connect to FTP server (port 21)
$conn_id = ftp_connect($host, 21) or die ("Cannot connect to host");
 
// send access parameters
ftp_login($conn_id, $usr, $pwd) or die("Cannot login");
 
// turn on passive mode transfers (some servers need this)
// ftp_pasv ($conn_id, true);

//  HTML file to move:
$local_html_file = './pages/'.$pid.'.htm';
$ftp_html_path = '/public_html/'.$pid.'.htm';
 
// perform SHTML file upload
$upload_html = ftp_put($conn_id, $ftp_html_path, $local_html_file, FTP_ASCII);