<?php

// Includes database connection
$root = $_COOKIE['root']; 
$db_file = $root.'/system/sqlite/feedback.db';
$db = new SQLite3($db_file);
   if(!$db) {
      echo $db -> lastErrorMsg();
   } else {
      $message = "Opened SQLite database";
   } 

// Makes query with rowid
$query = "SELECT rowid, * FROM feedback";

// Run the query and set query result in $result
// Here $db comes from "db_connection.php"
$result = $db->query($query);

?>
<!DOCTYPE html>
<html>
<head>
	<title>Data List</title>
</head>
<body>
	<div style="width: 600px; margin: 20px auto;">
		<a href="index.php">Add New</a>
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
				<td>Name</td>
				<td>Message</td>
				<td>Action</td>
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?php echo $row['name'];?><br><div class="muted small"><?php echo $row['date'];?></div></td>
				<td><?php echo $row['message'];?></td>
				<td> 
					<a href="delete.php?id=<?php echo $row['rowid'];?>" onclick="return confirm('Are you sure?');">Delete</a>
				</td>
			</tr>
			<?php } ?>
		</table>
	</div>
</body>
</html>