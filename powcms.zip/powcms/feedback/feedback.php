<?php 
ini_set('display_errors', '0');
// Includes database connection
$root = $_COOKIE['root']; 
//$db_file = $root.'/system/sqlite/feedback.db';
$db_file = 'feedback.db';
$db_backup = 'feedback_backup.db';

/* check db file size with backup to prevent over writing file with empty file */
$filesize_db = filesize($db_file );
$filesize_db_backup = filesize($db_backup);
if ($filesize_db < $filesize_db_backup) {
    copy($db_backup,$db_file);   
}

$db = new SQLite3($db_file);
   if(!$db) {
      echo $db -> lastErrorMsg();
   } else {
      $message = "Opened SQLite database";
   }  
   
// Makes query with row id
$query = "SELECT id, * FROM feedback ORDER BY date_added DESC LIMIT 50";

// Run the query and set query result in $result
$result = $db->query($query);   
   
$message = $_COOKIE['message'] ;  

if($_POST['submit_insert']) { 
$ip_address = $_SERVER['REMOTE_ADDR'];
$date = $_POST['date_added'] ;   
$name = $_POST['name'] ;      
$email = $_POST['email'] ; 
$message_type = $_POST['message_type'] ;
$message = $_POST['message'] ;         
$newsletter = $_POST['newsletter'] ; 
$country_code = $_POST['country_code'] ;
$country = $_POST['country'] ;
   
$date = date("Y-m-d H:i") ;
  
	// Makes query with post data
$query = "INSERT INTO feedback (date_added, ip_address, name, email, message_type, message, newsletter, country_code, country ) VALUES ('$date', '$ip_address', '$name', '$email', '$message_type', '$message', '$newsletter', '$country_code', '$country' )";
	// Executes the query
	// If data inserted then set success message otherwise set error message
	// Here $db comes from "db_connection.php"
	if( $db->exec($query) ){
		$message = "Data is inserted into <a href='/system/sqlite/phpliteadmin.php?table=pages&action=row_view' target='_blank' >SQLite</a>";
		setcookie('message', 'Thank you for your feedback.<br>It was inserted into the SQLite db' , time()+60 );
		// make a backup copy of db  
       copy($db_file,$db_backup);      
    /*   if(!copy($db_file,$db_backup))
       {echo "Failed to copy ". $db_file."<br>";}
         else
       {echo
       "Copied ".$db_file." into ".$db_backup."<br>";
      }   */ 
		header('Location: index.htm');
	}else{
		$message = "Sorry, Data is not inserted into <a href='/system/sqlite/phpliteadmin.php?table=pages&action=row_view' target='_blank' >SQLite</a>";
		setcookie('message', 'Sorry, your feedback was not inserted into the SQLite db' , time()+60 );
		header('Location: index.php');
	}
 } // end sqlite insert	

 
?>
<p>This is a HTML-PHP Hybrid "Module" PHP script that can be edited with TinyMCE Editor. This is how it works.</p>
<ol>
<li>index.htm reads the index_vars.js and loads the TinyMCE editable PHP/HTML page feedback.php.</li>
<li>Feedback.php reads and inserts submitted data in SQLite db feedback.db</li>
<li>The SQLite db feedback.db is copied/backuped to feedback_backup.db </li>
<li>If feedback.db is <> feedback_backup.db the backup is restored (to preserv db data when updating an online site) </li>
<li>jQuery Validate is used to validate input fields before submit.</li>
<li>User info messages are stored in a cookie for a minute.</li>
<li>You can edit/translate this script with the Page Editor</li>
<li>This Module/SQLite Db will be improved as a demo CRUD script. Date/Time stamp and IP-address is also inserted.</li>

</ol>                         
<form id="feedbackForm" class="" action="feedback.php" method="post">
<table class="table table-no-border" border="0" width="20%" cellspacing="2" cellpadding="2">
<tbody>
<tr>
<td>Status:</td>
<td><?php echo $message ;?></td>
</tr>
<tr>
<td>Name: (required)</td>
<td><input name="name" size="35" type="text" value="" /></td>
</tr>
<tr>
<td>Email: (required)</td>
<td><input name="email" size="35" type="text" /></td>
</tr>
<tr>
<td>Message type:</td>
<td><select name="message_type">
<option value="Undefined">Select Message Type</option>
<option value="Testimonial">Testimonial</option>
<option value="Bug">Bug Report</option>
<option value="Suggestion">Suggestion</option>
<option value="Comment">Comment</option>
</select></td>
</tr>
<tr>
<td>Message:</td>
<td><textarea cols="32" name="message" rows="4"></textarea></td>
</tr>
<tr>
<td>Subscribe to Newsletter:</td>
<td><input name="newsletter" size="35" type="checkbox" />   (If feature is ever implemented :-)</td>
</tr>
<tr>
<td>What is: 7+4=</td>
<td><input name="captcha" size="5" type="text" /></td>
</tr>
<tr>
<td></td>
<td><input class="button" name="submit_insert" type="submit" value="Send Feedback Message" /></td>
</tr>
</tbody>
</table>
</form><hr />
<div style="margin: 20px auto;">
<h2>Feedback Messages</h2>
<table class="table" border="0" width="90%" cellspacing="1" cellpadding="5">
<tbody>
<tr>
<td width="15%"><strong>Name</strong></td>
<td width="50%"><strong>Message</strong></td>
<td width="10%"><strong>Action</strong></td>
</tr>
<?php while($row = $result->fetchArray()) {?>
<tr>
<td><?php echo $row['name'];?><br />
<div class="small"><?php echo $row['date_added'];?></div>
</td>
<td><?php echo $row['message'];?></td>
<td> </td>
</tr>
<?php } ?></tbody>
</table>
</div>

<script src="/res/js/jquery.validate.min.js"></script>
<script>
$(document).ready(function () {

    $('#feedbackForm').validate({ // initialize the plugin
        rules: {
            email: {
                required: true,
                email: true
            },
            name: {
                required: true,
                minlength: 3
            },
           captcha: {
                required: true,
                number: true,
                min: 11,
                max: 11,
            }            
        }
    });

});
</script>    