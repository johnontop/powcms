<?php
ini_set('display_errors', '0'); 
ini_set('default_charset', 'UTF-8');
//header("Content-type: text/html; charset=utf-8; encoding=utf-8;");
//header("Content-type: text/html; charset=utf-8; ");            

/* COOKIE LOGIN CHECK - This will chack valid username and passwords - Change password in system/user-pass.php*/
include 'system/user-pass.php' ;

if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    
    if (($_COOKIE['username'] = $user) || ($_COOKIE['password'] = sha1($pass))) {            
        // echo 'Welcome back ' . $_COOKIE['username'];
    } else {        
        header('Location: http://localhost/pow-login.php');
    }    
  } else {
    header('Location: http://localhost/pow-login.php');    
  } // END COOKIE LOGIN CHECK
  
/*
shall be a modified copy of pow-edit.php

change header image
change header title
change scan folders
change update/download path
change web site


*/  
?>