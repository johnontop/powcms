<?php
ini_set('display_errors', '0'); 
ini_set('default_charset', 'UTF-8');

/* COOKIE LOGIN CHECK - These are our valid username and passwords - Change password in system/user-pass.php*/
include 'system/user-pass.php' ;

if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    
    if (($_COOKIE['username'] = $user) || ($_COOKIE['password'] = sha1($pass))) {            
        // echo 'Welcome back ' . $_COOKIE['username'];
    } else {        
        header('Location: http://localhost/pow-login.php');
    }    
  } else {
    header('Location: http://localhost/pow-login.php');    
  } // END COOKIE LOGIN CHECK
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8; encoding=utf-8" >
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">  

  <title>POW CMS Editor</title>
  
   <!-- Bootstrap -->
   <link href="http://localhost/res/bootstrap/bootstrap.min.css" rel="stylesheet">  
   
    <!-- Custom Fonts --> 
    <link href="http://localhost/res/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> 
   
    <!-- Custom styles for index.htm wrapper page -->
    <link href="http://localhost/res/default.css" rel="stylesheet">
    <link href="http://localhost/theme/default-mod.css" rel="stylesheet">   
    
    <style>

     .writing-file { /* position of folder info */
        position: absolute; 
        left: 1125px; 
        top: 70px;        
       }
       
     .folder-tree {  /* position of foler tree */
        position: absolute;  
        left: 1090px; 
        top: 180px;
     }
     
     .edit-vars {
        position: absolute;  
        left: 900px; 
        top: 105px;
     }     
     
      .vars-input {  /* input field labels */
        font-size: 11px;
        font-family:Arial; 
        font-weight:400;  
        margin-top:5px; 
        margin-bottom:2px;     
   } 
   
.custom-file-input::-webkit-file-upload-button {
  visibility: hidden;
}
.custom-file-input::before {
  content: url(http://localhost/res/open.png);
  display: inline-block;
 /* background: -webkit-linear-gradient(top, #f9f9f9, #e3e3e3);
  border: 1px solid #999;
  border-radius: 2px;
  margin-top:4px;
    text-shadow: 1px 1px #fff;
  font-weight: 700;
  font-size: 10pt;
  padding: 0px 0px;
  */
    
  outline: none;
  white-space: nowrap;
  -webkit-user-select: none;
  cursor: pointer;
}
.custom-file-input:hover::before {
  border-color: black;
}
.custom-file-input:active::before {
  background: -webkit-linear-gradient(top, #e3e3e3, #f9f9f9);
}      

.button {     /* https://catalin.red/just-another-awesome-css3-buttons/ */   
    display: inline-block;
    white-space: nowrap;
    background-color: #fafafa;
    background-image: linear-gradient(top, #fff, #ccc);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#eeeeee', EndColorStr='#cccccc');
    border: 1px solid #777;
    padding-top: 0px;
    padding-right: 8px;
    padding-bottom: 0px;
    padding-left: 8px;
    margin: 0.2em;
    font: Arial, Helvetica;
    font-weight:400;
    text-decoration: none;
    color: #333;
    text-shadow: 0 1px 0 rgba(255,255,255,.8);
    border-radius: 2px;
    box-shadow: 0 0 1px 1px rgba(255,255,255,.8) inset, 0 1px 0 rgba(0,0,0,.3);
}

.button:hover {
    background-color: #eee;        
    background-image: linear-gradient(top, #fafafa, #eee);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#fafafa', EndColorStr='#efffef');        
}

.button:active {
    box-shadow: 0 0 4px 2px rgba(0,0,0,.3) inset;
    position: relative;
    top: 1px;
}

.button:focus {
    outline: 0;
    background: #fafafa;
}    

.button:before {
    background: #eee;
    background: rgba(0,0,0,.1);
    float: left;        
    width: 1em;
    text-align: center;
    font-size: 13px;
    margin: 1 0.8em 0 -1em;
    padding: 0 .2em;
    box-shadow: 1px 0 0 rgba(0,0,0,.5), 2px 0 0 rgba(255,255,255,.5);
    border-radius: .15em 0 0 .15em;
    pointer-events: none;        
}

/* Hexadecimal entities for the icons */

.add:before {
    content: "\271A";
}

.edit:before {
    content: "\270E";        
}

.delete:before {
    content: "\2718";        
}

.save:before {
    content: "\2714";        
}

.email:before {
    content: "\2709";        
}

.like:before {
    content: "\2764";        
}

.next:before {
    content: "\279C";
}

.star:before {
    content: "\2605";
}

.spark:before {
    content: "\2737";
}

.play:before {
    content: "\25B6";
}
    </style>
    
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins and reading files via index_vars.js) -->
    <script src="http://localhost/res/js/jquery.min.js"></script>
    
    <!-- Colorbox jQuery CSS for html popu wih iframes, image slide shows, picture viewing -->
    <link href="http://localhost/res/colorbox/colorbox.css" rel="stylesheet"> 
     
    <!-- Colorbox jQuery plugin for html popu wih iframes, image slide shows, picture viewing -->
    <script src="http://localhost/res/colorbox/jquery.colorbox-min.js"></script>    
    
    <link rel="stylesheet" type="text/css" href="http://localhost/res/tooltip/tooltip.css">
    <script src="http://localhost/res/tooltip/tooltip.js" type="text/JavaScript"></script>   
    <script src="http://localhost/res/datetime/datetimepicker_css.js"></script> 
    
    <script src="index_vars.js"></script>

  <!-- This is the line that does almost everything. We can find it at http://www.tinymce.com/index.php  -->
  <!-- http://mesdomaines.nu/eendracht/rte/tinymce_explanations.html -->
  <script src="http://localhost/res/tinymce/tinymce.min.js"></script>

<script type="text/javascript">
tinymce.init({
        mode : "specific_textareas",
        editor_selector : "myBasicEditor", 
        //selector: ".",
        entity_encoding : "raw",
        height : "380px",
        theme: 'modern',
        plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "newdocument fullpage | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media code | insertdatetime preview | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",

        menubar: true,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],

        templates: [
                {title: 'Test template 1', content: 'Test 1'},
                {title: 'Test template 2', content: 'Test 2'}
        ],
        content_css: [
        'https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i'    
        ]        
});
</script>

</head>
<body onload = "tooltip.init ()">

      <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="http://localhost/"><img src="http://localhost/res/bar-logo.png" /></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
         <ul class="nav navbar-nav">      
            <li><a href="http://localhost/index.htm">Root</a></li>                                      
            <li><a href="http://localhost/pages">Pages</a></li>  
            <li><a href="http://localhost/pow-search.htm">Search</a></li>                                                                        
            <li><a href="http://localhost/templates">Templates</a></li>                                                               
            <li><a href="http://localhost/sysinfo">SysInfo</a></li> 
            <li><a href="http://localhost/sysinfo/Page Editor">Editor Help</a></li>
            <li><a href="http://localhost/pow-scan.php" title="This function will update the search function &lt;br /&gt; with the tags and description you have written" ><i class="fa fa-info-circle" ></i> Update Search</a></li>
            <li><a href="#" id="confirm" onclick="call_popup(); return false;" title="If you have created new sub folder this &lt;br /&gt; function  will copy needed files to the folders,&lt;br /&gt; so you can edit them." ><i class="fa fa-info-circle" ></i> Update Folders</a></li>
            
            <li><a href="http://localhost/pow-login.php">Logout</a></li>             
            <li><a href="javascript:history.go(-1)" title="Tooltip - "><i class="fa fa-arrow-circle-left" ></i> Back</a></li>               
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<!-- Thanks to http://www.dreamincode.net/forums/topic/9866-textarea-editor for the php part -->

  <script>    
   var loc = window.location.pathname;
   var dir = loc.substring(0, loc.lastIndexOf('/'));
   document.write("<p style='font-size:18px;position: relative;left: 60px; top: 5px;'>Edit Folder/File: " + dir + "/" + VARS.file_name + "</p>");       
  </script> 


<!-- - - - - - - reading index_vars.js - - - - - - - - -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - --> 
    
<?php  

$vars  = file_get_contents("index_vars.js"); 
//$vars = utf8_decode($vars);
          
preg_match('|VARS.title = "(.*)"|', $vars, $match) ; 
$title = $match[1];

preg_match('|VARS.author = "(.*)"|', $vars, $match) ; 
$name = $match[1];

preg_match('|VARS.data = "(.*)"|', $vars, $match) ;
$data = $match[1];

preg_match('|VARS.category = "(.*)"|', $vars, $match) ;
$category = $match[1];

preg_match('|VARS.file_name = "(.*)"|', $vars, $match) ;
$file_name = $match[1];

preg_match('|url : "(.*)"|', $vars, $match) ;
$load_file_not = $match[1];

preg_match('|VARS.date = "(.*)"|', $vars, $match) ;
$date = $match[1];

preg_match('|VARS.image = "(.*)"|', $vars, $match) ;
$image = $match[1];

preg_match('|VARS.description = "(.*)"|', $vars, $match) ; 
$description = $match[1];

preg_match('|VARS.tags = "(.*)"|', $vars, $match) ; 
$tags = $match[1];
//echo "Page tags: ".$tags;
//echo "<br><br>";
?>


<div style="display: inline; position: absolute; width:300px; left: 1000px; top: 500px; ">
<?php
// Test of folder paths
//echo "Path: ".realpath($load_file)." - " ;
//echo "Load: ".$load_file." - " ;
//echo "Save: ".$save_file ;
//echo getcwd() ;
//echo $file_name;
?>
</div>


<!-- - - - - - -  load HTML file choosen - - - - - - - -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - --> 

<?php
//$file = "tinymce_save";

$loadcontent = $file_name;
$fp = @fopen($loadcontent, "r");
$loadcontent = fread($fp, filesize($loadcontent));
//$loadcontent = utf8_decode(htmlspecialchars($loadcontent));
$loadcontent = htmlspecialchars($loadcontent);
fclose($fp); 

$load_file = $_POST['load_file'];  // Added
$save_file = $_POST['save_file'];
//$file_name = $_POST['file_name'];   
$savecontent = $_POST['savecontent'];

if($load_file) {
$loadcontent = $load_file;
// echo $loadcontent;
//$loadcontent = $file.".htm";
if (!is_writable($loadcontent)) {
echo '<font color="red" size="4" style="font-size:18px;position: relative;left: 60px; bottom: 5px;">Error - You can only open files in current folder</font> '.realpath($load_file);
} else {
$loadcontent = $load_file;
$fp = @fopen($loadcontent, "r");
$loadcontent = fread($fp, filesize($loadcontent));
//$loadcontent = utf8_decode(htmlspecialchars($loadcontent));
$loadcontent = htmlspecialchars($loadcontent);
fclose($fp);  

}
}

if($save_file) {
$loadcontent = $file_name; // added for test
$savecontent = stripslashes($savecontent);
$fp = @fopen($loadcontent, "w");
$loadcontent=$savecontent; // utf8 bom
if ($fp) {
//echo 'File Saved';
$status = 'File Saved';
//fwrite($fp, utf8_encode($savecontent));
fwrite($fp, pack("CCC",0xef,0xbb,0xbf)); 
fwrite($fp, $savecontent);
fclose($fp);
}
}  // end save file

?>

<!-- - - - - - - - show TinyMCE section - - - - - - - -->
<!-- - - - - - - - - - - - - -  - - - - - - - - - - - --> 

<form action="<?=$_SERVER['PHP_SELF']?>"  method="post">
<div style="display: inline; position: relative; width:600px; left: 33px; top: 0px; right: 20px;">
<label for="choose" class="button">Open File</label>
<input style="display: inline;display:none;" type="file" id="choose" name="load_file" title="Browse files in current folder.&lt;br /&gt; Then click load button." accept=".htm,.html" value="./">
<input style="display: inline;" class="button" type="submit" value="Load"> 
Name: <input style="display: inline;" type="text" name="file_name" value="<?php echo $load_file ;?>" > 
<input type="button" onclick="location.href='index.htm';" class="button" title="Tooltip - " value="View Page" />
<a href="#" class="iframe" onclick="location.href='index.htm';" ><img src="http://localhost/res/view.png" title="Experimental popup view of doc"></a>
<a href="http://localhost/pow-word.php"><img src="http://localhost/res/word.png" title="Experimental create Word doc"></a>
</div>
</form>

<form style="position: relative; width:780px; left: 35px; top: 10px;" enctype="multipart/form-data" method="post" action="<?=$_SERVER['PHP_SELF']?>">
<textarea  class="myBasicEditor" name="savecontent" id="savecontent" >
<?=$loadcontent?>
</textarea>

<input type="submit" name="save_file" value="Save" style="position: absolute; top:2px; right: 2px; color:#009933 ;">  
<div style="position: absolute; top:2px; right: 80px"><?php echo $status ;?></div>
<input type="hidden" name="file_name" value="<?php echo $load_file ;?>">
</form>

<?php
if($_POST['submit_vars']) {
$title = $_POST['title'];
$name = $_POST['name'];
$file_name = $_POST['file_name']; 
$data = $_POST['data'];
$date = $_POST['date'];
$category = $_POST['category'];
$image = $_POST['image']; 
$tags = $_POST['tags'];
$description = $_POST['description'];
}
?>                                    

<div style="display: inline; position: absolute; width:250px; left: 850px; top: 70px;">
    <form id="regexp" class="" method="post" action="pow-edit.php">
					
		<h4>Page Variables</h4>
		
		<div>
		  <label class="vars-input" for="name" title="Tooltip - "><i class="fa fa-info-circle" ></i> Page Title - Title shown on top of page (<font color="red">required</font>)</label>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo $title ;?>"/> 
		</div> 

		<div>
		  <label class="vars-input" for="file_name" title="Tooltip - "><i class="fa fa-info-circle" ></i> File Name - File loaded into web page (<font color="red">required</font>)</label>
			<input id="file_name" name="file_name" class="element" type="text" maxlength="255" size="35" value="<?php echo $file_name ;?>"/> 
		</div> 		  		
	
		<div>
		  <label class="vars-input" for="data" title="Tooltip - "><i class="fa fa-info-circle" ></i> Data ID - Used as value in database (optional)</label>
			<input id="data" name="data" class="element" type="text" maxlength="255"  size="35" value="<?php echo $data ;?>"/> 
		</div> 

		<div>
		  <label class="vars-input" for="category" title="Tooltip - "><i class="fa fa-info-circle" ></i> Category - Used as value in database (optional) </label>
			<input id="category" name="category" class="element" type="text" maxlength="255" size="35" value="<?php echo $category ;?>"/> 
		</div>      

		<div>
		  <label class="vars-input" for="date" title="Date/time will be used for search functions - "><i class="fa fa-info-circle" ></i> Date - For coming functions (adviced)</label>
			<input id="date" name="date" class="element" type="text" maxlength="255" size="30" value="<?php echo $date ;?>"/> 
			<img src="http://localhost/res/datetime/images2/cal.gif" onclick="javascript:NewCssCal('date','yyyyMMdd','dropdown',true,'24')"  style="cursor:pointer"/>
		</div>      

		<div>
		  <label class="vars-input" for="name" title="Author - the authors name"><i class="fa fa-info-circle" ></i> Author - Title shown on top of page (adviced)</label>
			<input id="name" name="name" class="element" type="text" maxlength="255" size="35" value="<?php echo $name ;?>"/> 
		</div>              			
    		
		<div>
		  <label class="vars-input" for="tags" title="Tag Words - to keep an name intact in the 'Tag Search' use an underscore instead of the space character."><i class="fa fa-info-circle" ></i> Page Tags - Used in search function (<font color="red">required</font>)</label>
			<input id="tags" name="tags" class="element" type="text" maxlength="255" size="35" value="<?php echo $tags ;?>"/> 
		</div> 
        		
		<div>
		  <label class="vars-input" for="description" title="This is the description shown in the search function. Don´t use characters like single or double quotes in the text, since it will cause the search to stop working"><i class="fa fa-info-circle" ></i> Description - Used in search function (<font color="red">required</font>)</label>
			<textarea id="description" name="description" cols="40" rows="6" class="element textarea small"><?php echo $description ;?></textarea> 
		</div> 
		
		<div>
		  <label class="vars-input" for="image" title="Tooltip - "><i class="fa fa-info-circle" ></i> Image - Load image into themes (optional)</label>
			<input id="image" name="image" class="element" type="text" maxlength="255" size="31" value="<?php echo $image ;?>"/> 
			<label class="custom-file-input"  for="Upload" ></label><input id="Upload" style="padding-top:20x; display:none;" type="file" multiple="multiple" name="_photos" accept="image/*" style="visibility: hidden">
		</div> 
    		
     
    <input id="saveForm" class="button" type="submit" name="submit_vars" value=" Update Page Variables " />     
    
    <!-- 
     <input type="hidden" name="form_id-not" value="regex" />
     <input type="button" onclick="location.href='pow-vars.php';" value="Edit Page Variables" />
    <input id="saveForm" class="button_text" type="submit" name="submit" value="Update Page Variables" /> 
    <input type="button" onclick="location.href='pow-edit.php';" value="Edit Page" />
    -->

		</form>	
    </div>
    
    <div style="position: absolute; left: 1130px; top: 530px;"> 
     <img src="<?php echo $image ;?>" height="100px" />
     <p class="small"><?php echo $image ;?></p> 
    </div> 
     
     
<!-- - - - - - - writing search_vars.txt - - - - - - - -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - -->     

<?php
//$description = htmlspecialchars($description);
if($_POST['submit_vars']) {
$description = str_replace('"', "'", $description);
$description = trim( str_replace( PHP_EOL, ' ', $description ) );
//$description = preg_replace('/\r?\n$/', ' ', $description);
$search_text = '{"title": "'.$title.'", "text": "'.$description.'", "tags": "'.$tags.'", "date": "'.$date.'", "url": "http://localhost'. dirname($_SERVER['PHP_SELF']) .'/index.htm"},' ;
//$search_text = utf8_encode($search_tex);

//echo "<br>".$search_text."<br><br>";

$search_vars  = fopen("search_vars.txt", "w") or die("Unable to open file!");
fwrite($search_vars, pack("CCC",0xef,0xbb,0xbf));   
fwrite($search_vars, $search_text);
fclose($search_vars); 
} 
?>

<!-- - - - - - - - writing index_vars.js - - - - - - - -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - -->  

<?php

if($_POST['submit_vars']) {
$index_text = '    VARS = {};
    VARS.title = "'.$title.'";
    VARS.author = "'.$name.'";
    VARS.file_name = "'.$file_name.'";
    VARS.data = "'.$data.'";
    VARS.category = "'.$category.'";
    VARS.date = "'.$date.'";
    VARS.image = "'.$image.'";
    VARS.tags = "'.$tags.'";
    VARS.description = "'.$description.'";
                
        $.ajax({            
            url : "'.$file_name.'",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src='.$image.'>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});             
            ' ;
        

$index_vars  = fopen("index_vars.js", "w") or die("Unable to open file!"); 
fwrite($index_vars, pack("CCC",0xef,0xbb,0xbf));  
//fwrite($index_vars, utf8_encode($index_text));
fwrite($index_vars, $index_text);
fclose($index_vars); 

$search_tags  = fopen("search_tags.txt", "w") or die("Unable to open file!"); 
fwrite($search_tags, pack("CCC",0xef,0xbb,0xbf));  
fwrite($search_tags, $tags.' ');
fclose($search_tags); 
} 

?>   

<!-- - - - - - - showing side-folders.htm  - - - - - - -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - -->

<div class="folder-tree"> 

<?php 
$directories = scandir('./');

echo '<ul>'; 

foreach($directories as $directory){
      
    if($directory=='.' ){
        echo '<b style="margin-left: 0px;">Edit Folder Pages</b>';
    }   
    else if ( $directory=='..'){
        echo '<li style="list-style-type: none;"><a href="javascript:history.go(-2)">&#x21E6; Up</a></li>';        
    }   
  else if ( $directory=='res'){
       echo '<li style="list-style-type: none;"><a href="res/pow-edit.php">&#x2692; Res (hidden)</a></li>';
       // echo '';
    } 
  else if ( $directory=='theme'){
       echo '<li style="list-style-type: none;"><a href="theme/pow-edit.php">&#x2692; Theme (hidden)</a></li>';
       // echo '';
    }     
  else if ( $directory=='system'){
       echo '<li style="list-style-type: none;"><a href="system/pow-edit.php">&#x2692; System (hidden)</a></li>';
       // echo '';
    }           
    else{               
         if(is_dir($directory)){                  
            echo '<li style="list-style-type: none;"><a href="'.$directory .'/pow-edit.php">&#x2692; '.ucfirst($directory).'</a></li>';                            
         }
    }
} 
echo '</ul>'; 

?>
</div>  <!-- end showing side-folders.htm -->

<!-- - - - - - - writing side-folders.htm  - - - - - - -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - -->

<div class="writing-file"> 

<h4>Folders</h4>

<?php

$myfile = fopen("side-folders.htm", "w") or die("Unable to open file!");

$directories = scandir('./');

$txt = '<ul class="side-pages">'. PHP_EOL; 
//fwrite($myfile, pack("CCC",0xef,0xbb,0xbf)); // Creates UTF-8 file
fwrite($myfile, $txt);

foreach($directories as $directory){
      
    if($directory=='.' ){
        echo '<b>Writing Folder File</b><br>side-folders.htm<br>';
    }          
      
    else if ( $directory=='..'){
         '<li><a href="../">Up</a></li>';
        
    }  
      else if ( $directory=='res'){
       // echo '<li><a href="../">Resources</a></li>';
        echo '';
    } 
      else if ( $directory=='theme'){
       // echo '<li><a href="../">Theme</a></li>';
        echo '';
    }     
      else if ( $directory=='system'){
       // echo '<li><a href="../">System</a></li>';
        echo '';
    }         
    else{
               
            if(is_dir($directory)){
                  
                  $txt = '<li><a href="'.$directory.'">'.ucfirst($directory).'</a></li>'. PHP_EOL;
                  fwrite($myfile, $txt);
            }
    }
} 

$txt = '</ul>'. PHP_EOL; 
fwrite($myfile, $txt);
fclose($myfile); 
//echo '<div>File written</div>';
?> 
<progress value="0" max="8" id="progressBar"></progress>
</div>   

<script>
function size_it()
{
//Specifying the height of the field where the edits are done. You may have to alter the pixel-value (method: trial and error)
document.getElementById('savecontent').style.height=window.innerHeight-150+'px'
}
size_it()   
</script>

<script>
var timeleft = 5;
var downloadTimer = setInterval(function(){
  document.getElementById("progressBar").value = 10 - --timeleft;
  if(timeleft <= 0)
    clearInterval(downloadTimer);
},500);
</script>

<script type="text/javascript">
function call_popup()
{

jQuery.colorbox({width:"550px", height:"330px",html:'<div class="modal-body"><h3>Scanning Folders and Updating Files!</h3><ul><li>This will take a couple of seconds</li><li>Coyping files and updating folders</li><li>Scanning folders for Word Tags and descriptions</li><li>Writing file for Search function</li><li>Updating Search function</li><br><progress value="0" max="8" id="updateBar"></progress></ul></div>'});

            $('#cboxClose').remove();
            setTimeout(function(){
              $(window).colorbox.close();
            }, 7000)
            
$.ajax({ 
    url: "http://localhost/pow-update.php",
    success: 
        function(data)
        {
           // here, for example, you load the data received from pow-update.php into
           // an html element with id #content and show an alert message
           // $("#content").html(data);
           // alert("Success")
        }
});   

var timeleft = 10;
var downloadTimer = setInterval(function(){
  document.getElementById("updateBar").value = 10 - --timeleft;
  if(timeleft <= 0)
    clearInterval(downloadTimer);
},800);       
           
}
</script>



    <!-- Bootstrap Core JavaScript -->
    <script src="http://localhost/res/bootstrap/bootstrap.min.js"></script>

</body>
</html> 