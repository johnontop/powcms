 VARS.lang_code = "en";
 VARS.language = "English";
 VARS.system_version = "0.8"; 
 VARS.system_title = "Portable Offline Web CMS";  // main page header index.htm
 VARS.system_tagline = "Rocks the world!";        // main page header index.htm
 VARS.system_image = "/theme/header-image.png";   // main page header index.htm
 VARS.topbar_image = "/theme/topbar-logs.png";   // main page header index.htm
 
 VARS.pages_side = "Pages";    // side menu index.htm
 VARS.links_side = "Links";    // side menu index.htm
 VARS.version_history = "Version History";  // side menu index.htm           
 VARS.licenses = "Licenses";                // side menu index.htm
 
 VARS.copyright = "Portable Offline Web CMS - 2017";  // main page foot index.htm
 VARS.page_top = "Page Top!";   // main page foot index.htm
 
 VARS.title_status = "Title";       // status index.htm
 VARS.page_status = "Page";         // status index.htm
 VARS.data_status = "Data ID";      // status index.htm
 VARS.category_status = "Category"; // status index.htm
 VARS.edit = "Edit Page";           // status index.htm

 VARS.start = "Start Page";       // side-pages.htm menu 
 VARS.previous = "Previous Page";  // side-pages.htm menu
 VARS.next = "Next Page";          // side-pages.htm menu  
 
 VARS.root = "Start";          // top menu
 VARS.search = "Search";       // top menu
 VARS.pages = "Pages";         // top menu
 VARS.index = "Index";         // top menu
 VARS.content = "Content";     // top menu 
 VARS.templates = "Templates"; // top menu
 VARS.sysinfo = "System Info"; // top menu
 VARS.back = "Back";           // top menu
 

 
