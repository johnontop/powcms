﻿    VARS = {};
    VARS.title = "Portable Offline Web CMS";
    VARS.author = "admin";
    VARS.file_name = "readme.htm";
    VARS.data = "page-readme";
    VARS.category = "Sysinfo";
    VARS.date = "2017-09-30 19:03";
    VARS.image = "";
    VARS.tags = "Portable_Offline_Web_CMS";
    VARS.description = "Portable Offline Web CMS The Portable Offline Web CMS (POW CMS) is a very easy way to build and view an offline web site. Upload POW CMS to an Online webserver and it works directly without configuration.";
                
        $.ajax({            
            url : "readme.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "/theme/side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "/theme/side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});   
            
        
    // Get Links Side menu
        $.ajax({
            url : "/theme/side-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textSideMenu").html(data); }});                         
            
    // Get Links top menu
        $.ajax({
            url : "/theme/top-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textMenuID").html(data); }});            
            
            