<?php
// This file shall in "some way" copy pow-edit.php, index.htm, side-pages.htm, info.htm - to pages sub folders.

/* Copy files and folder recursive
$source = 'text.txt';
$$dest = 'text.txt';
// copy recursive
function cpy($source, $dest){
    if(is_dir($source)) {
        $dir_handle=opendir($source);
        while($file=readdir($dir_handle)){
            if($file!="." && $file!=".."){
                if(is_dir($source."/".$file)){
                    if(!is_dir($dest."/".$file)){
                        mkdir($dest."/".$file);
                    }
                    cpy($source."/".$file, $dest."/".$file);
                } else {
                    copy($source."/".$file, $dest."/".$file);
                }
            }
        }
        closedir($dir_handle);
    } else {
        copy($source, $dest);
    }
}

cpy($source, $dest);
*/

// cmdow /run /hid mybat arg1 "arg 2"
header('Location: ./pow-scan.php');
$updatefiles = "CopyFiles.bat";
exec("start /MIN $updatefiles");
echo "Finished";
//header('Location: ./pow-scan.php');
exit; 
?>