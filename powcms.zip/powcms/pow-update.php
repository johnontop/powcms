<?php
// This file shall in "some way" copy pow-edit.php, index.htm, side-pages.htm, info.htm - to pages sub folders.
$updatefiles = "CopyFiles.bat";
exec("start $updatefiles");
echo "Finished";
header('Location: ./index.htm');
exit;
?>