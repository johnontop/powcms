<?php
// This code will be implemented into pow-scan.php
// It will generate a htm file "search_tags.htm" that will show up as a "tag cloud" in the search page.

ini_set('display_errors', '1');
//$search_tags  = file_get_contents($item['name']."/search_vars.txt");  // for pow-scan.php
//$string  = file_get_contents("search_tags.htm");  // for pow-scan.php   
$string  = file_get_contents("search_tags.htm");  // for pow-scan.php
//$string = "one one two three two three three three three three three four nine  eight";

function sortstring($string,$unique = false) {
  $string = str_replace('.', '', $string);
  $string = str_replace('.', '', $string);
  $array = explode(' ',strtolower($string)); 
  if ($unique) $array = array_unique($array);
  sort($array);
  return implode(' ',$array);  
}

$string = sortstring($string) ;
//$string = sortstring($string,$unique = false)


$string = preg_replace("/([,.?!])/"," \\1",$string);
$parts = explode(" ",$string);
$unique = array_unique($parts);
//$unique = sort($unique);
$unique = implode(" ",$unique);
$unique = preg_replace("/\s([,.?!])/","\\1",$unique);

echo $unique.'<br>';
$search_tags  = fopen("search_tags.htm", "w") or die("Unable to open file!"); 
fwrite($search_tags, pack("CCC",0xef,0xbb,0xbf));
  
      $Array  = explode(' ',$unique) ;

      foreach($Array  as $key => $value) {
      // print "$key: $value<br>"; 
      $tag = ' <a class="tag_word" href="http://localhost/pow-search.htm?q='.$value.'">'.$value.'</a> ';
      echo $tag ;
      file_put_contents("search_tags.htm", $tag, FILE_APPEND);	   
      }
      
;  
fwrite($search_tags, $tag.' ');
fclose($search_tags);       
?>      