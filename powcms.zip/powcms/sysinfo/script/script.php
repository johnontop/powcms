<?php 
$root = $_COOKIE['root']; 
$db_file = $root.'/system/sqlite/powcms.db';
$db = new SQLite3($db_file);
   if(!$db) {
      echo $db -> lastErrorMsg();
   } else {
      $message = "Opened SQLite database";
   }  
$date = date("Y-m-d H:i") ;
$var1 ="Hello World";
$var2 ="PHP echo text of variable";
?>
<p>This is a test of a PHP-HTML Hybrid Script with TinyMCE Editor. The folder "script" can be deleted.</p>
<ol>
<li>index.php loads index.htm with current theme and shows design</li>
<li>index.htm reads the index_vars.js and loads the TinyMCE edited PHP/HTML page.</li>
<li>index.php can insert and update data, while script.php can read data</li>
</ol>
<br />Currently the script does nothing.<br /> <?php echo $var1 ;?><br /> <?php echo $var2 ;?><br /><br /><?php echo $message ;?>
<table class="table table-no-border" border="0" width="20%" cellspacing="2" cellpadding="2">
<tbody>
<tr>
<td>Name:</td>
<td><input name="name" size="35" type="text" value="<?php echo $var1 ;?>" /></td>
</tr>
<tr>
<td>Email:</td>
<td><input name="email" size="35" type="text" /></td>
</tr>
<tr>
<td>Message type:</td>
<td><select>
  <option value="Undefined">Select Message Type</option>
  <option value="Testamonial">Testamonial</option>
  <option value="Bug">Bug Report</option>
  <option value="Suggestion">Suggestion</option>
  <option value="Comment">Comment</option>
</select></td>
</tr>
<tr>
<td>Message:</td>
<td><textarea cols="32" rows="4">This is an experimental test to how PHP and SQLite can be implemented into POWCMS with TinyMCE.
</textarea> </td>
</tr>
<tr>
<td>What is: 7+4=</td>
<td><input name="catcha" size="5" type="text" /></td>
</tr>
<tr>
<td><a href="list.php">See Data</a></td>
<td><input name="submit_insert" type="submit" value="Send Message" /></td>
</tr>
</tbody>
</table>
<br /> <br /><form id="myForm" class="" action="index.php" method="post"><input id="saveForm" class="button" name="submit" type="submit" value="Apply Page Design" /></form>