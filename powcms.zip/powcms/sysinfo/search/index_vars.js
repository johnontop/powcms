﻿    VARS = {};
    VARS.title = "Search function";
    VARS.author = "admin";
    VARS.file_name = "search.htm";
    VARS.data = "page-search";
    VARS.category = "System";
    VARS.date = "2017-09-09 00:47";
    VARS.image = "";
    VARS.tags = "Search Tipue Tags";
    VARS.description = "Learn how the search function works. The search function is developed by Tipue. Tipue can do free text search from the text in the page description text. It reads the file 'search content.js' in the root folder.";
                
        $.ajax({            
            url : "search.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "/theme/side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "/theme/side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});             
            
    // Get Links top menu
        $.ajax({
            url : "/theme/top-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textMenuID").html(data); }});            
            
            