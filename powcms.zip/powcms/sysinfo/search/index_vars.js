﻿    VARS = {};
    VARS.title = "Search function";
    VARS.name = "Search function";
    VARS.file_name = "search.htm";
    VARS.data = "page-search";
    VARS.category = "";
    VARS.date = "2017-09-09 00:47";
    VARS.image = "";
    VARS.tags = "Search Tipue";
    VARS.description = "Read how the search function works.";
                
        $.ajax({            
            url : "search.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});             
            