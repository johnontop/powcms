﻿    VARS = {};
    VARS.title = "Info & Help";
    VARS.author = "admin";
    VARS.file_name = "info.htm";
    VARS.data = "page-sysinfo";
    VARS.category = "None";
    VARS.date = "2017-09-11 02:55";
    VARS.image = "/theme/header-image.png";
    VARS.tags = "System Info Help ";
    VARS.description = "Here is where you can find all info about the aspects of Portable Offline Web CMS system. How it, works, best practice and help info. We appreciate feedback on tip to improve the documentation.";
                
        $.ajax({            
            url : "info.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=/theme/header-image.png>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "/theme/side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "/theme/side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});   
            
        
    // Get Links Side menu
        $.ajax({
            url : "/theme/side-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textSideMenu").html(data); }});                         
            
    // Get Links top menu
        $.ajax({
            url : "/theme/top-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textMenuID").html(data); }});            
            
            