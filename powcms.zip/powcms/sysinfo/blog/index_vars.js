﻿    VARS = {};
    VARS.title = "Simple Blog";
    VARS.author = "admin";
    VARS.file_name = "blog.htm";
    VARS.data = "page-blog";
    VARS.category = "System";
    VARS.date = "2017-09-11 03:14";
    VARS.image = "";
    VARS.tags = "Blog Date Latest Post";
    VARS.description = "Here is where the latest posts will show. For this feature the Data ID variable and a database have to be used. The database script will generate a HTML file wit the latest 25 posts that links to the pages. This wil be a simulation of popular blogs like Wordpress and others.";
                
        $.ajax({            
            url : "blog.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "/theme/side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "/theme/side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});   
            
        
    // Get Links Side menu
        $.ajax({
            url : "/theme/side-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textSideMenu").html(data); }});                         
            
    // Get Links top menu
        $.ajax({
            url : "/theme/top-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textMenuID").html(data); }});            
            
            