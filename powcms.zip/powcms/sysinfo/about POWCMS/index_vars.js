﻿    VARS = {};
    VARS.title = "About";
    VARS.author = "admin";
    VARS.file_name = "about.htm";
    VARS.data = "page-about";
    VARS.category = "sysinfo";
    VARS.date = "2017-09-10 01:56";
    VARS.image = "";
    VARS.tags = "About POW";
    VARS.description = "The Portable Offline Web CMS allows you to creates web pages and arrange them to a complete web site. When you are finished with editing you web pages, you can Copy the folder tree to a USB stick and view your web site on any computer Zip the whole folder and upload to a file share, so other can download the web site and view it Upload the folder tree to a web server online.";
                
        $.ajax({            
            url : "about.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "/theme/side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "/theme/side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});             
            
    // Get Links top menu
        $.ajax({
            url : "/theme/top-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textMenuID").html(data); }});            
            
            