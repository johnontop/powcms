<?php
// do stuff

include "index.htm" ;

?>