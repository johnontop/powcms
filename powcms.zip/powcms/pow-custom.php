<?php
ini_set('display_errors', '0'); 
ini_set('default_charset', 'UTF-8');
//header("Content-type: text/html; charset=utf-8; encoding=utf-8;");
//header("Content-type: text/html; charset=utf-8; ");            

/* COOKIE LOGIN CHECK - This will chack valid username and passwords - Change password in system/user-pass.php*/
include 'system/user-pass.php' ;

if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    
    if (($_COOKIE['username'] = $user) || ($_COOKIE['password'] = sha1($pass))) {            
        // echo 'Welcome back ' . $_COOKIE['username'];
    } else {        
        header('Location: http://localhost/pow-login.php');
    }    
  } else {
    header('Location: http://localhost/pow-login.php');    
  } // END COOKIE LOGIN CHECK
  
$root = $_COOKIE['root'];  
include $root . '/theme/translation.php';   
  
/*
shall be a modified copy of pow-edit.php

change header image
change header title
change scan folders
change update/download path
change web site


*/  
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8; encoding=utf-8" >
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">  

  <title>POW Translate & Customize</title>
  
   <!-- Bootstrap -->
   <link href="/res/bootstrap/bootstrap.min.css" rel="stylesheet">  
   
    <!-- Custom Fonts --> 
    <link href="/res/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> 
   
    <!-- Custom styles for index.htm wrapper page -->
    <link href="/res/default.css" rel="stylesheet">
    <link href="/theme/default-mod.css" rel="stylesheet">   
    
    <style>
    
      .fa-pencil-square-o { 
       color:#333;
      }  
      
     input[type=text] {       
       padding-top: 0px;
       padding-left: 5px;
       padding-bottom: -0px;
       padding-right: 1px;
       height:22px;              
      }

     .writing-file { /* position of folder info */
        position: absolute; 
        left: 1125px; 
        top: 55px;        
       }
       
     .folder-tree {  /* position of foler tree */
        position: absolute;  
        left: 1090px; 
        top: 165px;
     }
     
     .edit-vars {
        position: absolute;  
        left: 900px; 
        top: 105px;
     }     
     
      .vars-input {  /* input field labels */
        font-size: 11px;
        font-family:Arial; 
        font-weight:400;  
        margin-top:5px; 
        margin-bottom:2px;     
   } 
   
.custom-file-input::-webkit-file-upload-button {
  visibility: hidden;
}
.custom-file-input::before {
  content: url(/res/open.png);
  display: inline-block;
 /* background: -webkit-linear-gradient(top, #f9f9f9, #e3e3e3);
  border: 1px solid #999;
  border-radius: 2px;
  margin-top:4px;
    text-shadow: 1px 1px #fff;
  font-weight: 700;
  font-size: 10pt;
  padding: 0px 0px;
  */
    
  outline: none;
  white-space: nowrap;
  -webkit-user-select: none;
  cursor: pointer;
}
.custom-file-input:hover::before {
  border-color: black;
}
.custom-file-input:active::before {
  background: -webkit-linear-gradient(top, #e3e3e3, #f9f9f9);
}      

.button {     /* https://catalin.red/just-another-awesome-css3-buttons/ */   
    display: inline-block;
    white-space: nowrap;
    background-color: #ddd;
    background-image: -webkit-gradient(linear, left top, left bottom, from(#eee), to(#ccc));
    background-image: -webkit-linear-gradient(top, #eee, #ccc);
    background-image: -moz-linear-gradient(top, #f3f3f3, #ddd);
    background-image: -ms-linear-gradient(top, #eee, #ccc);
    background-image: -o-linear-gradient(top, #eee, #ccc);
     background-image: linear-gradient(top, #f3f3f3, #ddd);
            
    border: 1px solid #777;
    padding-top: 0px;
    padding-right: 8px;
    padding-bottom: 0px;
    padding-left: 8px;
    margin: 0.2em;
    font: Roboto, Arial, Helvetica;
    font-weight:400;
    text-decoration: none;
    color: #222;
    text-shadow: 0 1px 0 rgba(255,255,255,.8);
    border-radius: 2px;
    box-shadow: 0 0 1px 1px rgba(255,255,255,.8) inset, 0 1px 0 rgba(0,0,0,.3);
}

.button:hover {
    background-color: #eee;        
    background-image: -webkit-gradient(linear, left top, left bottom, from(#fafafa), to(#ddd));
    background-image: -webkit-linear-gradient(top, #fafafa, #ddd);
    background-image: -moz-linear-gradient(top, #fafafa, #ddd);
    background-image: -ms-linear-gradient(top, #fafafa, #ddd);
    background-image: -o-linear-gradient(top, #fafafa, #ddd);
    background-image: linear-gradient(top, #fafafa, #ddd);     
}

.button:active {
    -moz-box-shadow: 0 0 4px 2px rgba(0,0,0,.3) inset;
    -webkit-box-shadow: 0 0 4px 2px rgba(0,0,0,.3) inset;
     box-shadow: 0 0 4px 2px rgba(0,0,0,.3) inset;
     position: relative;
     top: 1px;
}

.button:focus {
    outline: 0;
    background: #fafafa;
}    

.button:before {
    background: #eee;
    background: rgba(0,0,0,.1);
    float: left;        
    width: 1em;
    text-align: center;
    font-size: 13px;
    margin: 1 0.8em 0 -1em;
    padding: 0 .2em;
    box-shadow: 1px 0 0 rgba(0,0,0,.5), 2px 0 0 rgba(255,255,255,.5);
    border-radius: .15em 0 0 .15em;
    pointer-events: none;        
}

/* Hexadecimal entities for the icons 
https://www.computerhope.com/htmcolor.htm
*/

.blue-bg {
   background-color: #E1FFD6;
}

.add:before {
    content: "\271A";
}

.edit:before {
    content: "\270E";        
}

.delete:before {
    content: "\2718";        
}

.save:before {
    content: "\2714";        
}

.email:before {
    content: "\2709";        
}

.like:before {
    content: "\2764";        
}

.next:before {
    content: "\279C";
}

.star:before {
    content: "\2605";
}

.spark:before {
    content: "\2737";
}

.play:before {
    content: "\25B6";
}
    </style>
    
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins and reading files via index_vars.js) -->
    <script src="/res/js/jquery.min.js"></script>
    
    <!-- Colorbox jQuery CSS for html popu wih iframes, image slide shows, picture viewing -->
    <link href="/res/colorbox/colorbox.css" rel="stylesheet"> 
     
    <!-- Colorbox jQuery plugin for html popu wih iframes, image slide shows, picture viewing -->
    <script src="/res/colorbox/jquery.colorbox-min.js"></script>    
    
    <link rel="stylesheet" type="text/css" href="/res/tooltip/tooltip.css">
    <script src="/res/tooltip/tooltip.js" type="text/JavaScript"></script>   
    <script src="/res/datetime/datetimepicker_css.js"></script> 
    
    <script src="index_vars.js"></script>
    <script src="pow_vars.js"></script>

  <!-- This is the line that does almost everything. We can find it at http://www.tinymce.com/index.php  -->
  <!-- http://mesdomaines.nu/eendracht/rte/tinymce_explanations.html -->
  <script src="/res/tinymce/tinymce.min.js"></script>

<script type="text/javascript">
tinymce.init({
        mode : "specific_textareas",
        editor_selector : "myBasicEditor", 
        spellchecker_rpc_url: 'spellchecker.php',
        //selector: ".",
        entity_encoding : "raw",
        force_br_newlines : true,
        force_p_newlines : false,
        forced_root_block : '',
        height : "380px",
        theme: 'modern',
        plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste textcolor colorpicker textpattern"
        ],

        toolbar1: "newdocument fullpage | bold italic underline strikethrough | forecolor backcolor | alignleft aligncenter alignright alignjustify | formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media | insertdatetime preview code ",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft styleselect ",

        menubar: true,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],

        templates: [
                {title: '2 column', content: '	<div class="row"><div class="col-md-6">First</div><div class="col-md-6">Second</div></div>'},
                {title: 'Test template 2', content: 'Test 2'}
        ],
        content_css: [
        'https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i'    
        ]        
});
</script>

<?php  

$vars  = file_get_contents("pow_vars_org.js"); 
//$vars = utf8_decode($vars);
   
preg_match('|VARS.lang_code = "(.*)"|', $vars, $match) ; 
$lang_code = $match[1];

preg_match('|VARS.language = "(.*)"|', $vars, $match) ; 
$language = $match[1];
                    
preg_match('|VARS.system_title = "(.*)"|', $vars, $match) ; 
$system_title = $match[1];

preg_match('|VARS.system_tagline = "(.*)"|', $vars, $match) ; 
$system_tagline = $match[1];

preg_match('|VARS.system_version = "(.*)"|', $vars, $match) ; 
$system_version = $match[1];

preg_match('|VARS.system_image = "(.*)"|', $vars, $match) ; 
$system_image = $match[1];

preg_match('|VARS.topbar_image = "(.*)"|', $vars, $match) ; 
$topbar_image = $match[1];

preg_match('|VARS.author = "(.*)"|', $vars, $match) ; 
$name = $match[1];

preg_match('|VARS.data = "(.*)"|', $vars, $match) ;
$data = $match[1];

preg_match('|VARS.category = "(.*)"|', $vars, $match) ;
$category = $match[1];

preg_match('|VARS.file_name = "(.*)"|', $vars, $match) ;
$file_name = $match[1];

preg_match('|url : "(.*)"|', $vars, $match) ;
$load_file_not = $match[1];

preg_match('|VARS.date = "(.*)"|', $vars, $match) ;
$date = $match[1];

preg_match('|VARS.image = "(.*)"|', $vars, $match) ;
$image = $match[1];

preg_match('|VARS.description = "(.*)"|', $vars, $match) ; 
$description = $match[1];

preg_match('|VARS.tags = "(.*)"|', $vars, $match) ; 
$tags = $match[1];
//echo "Page tags: ".$tags;
//echo "<br><br>";
?>

</head>
<body onload = "tooltip.init ()">

      <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/"><img src="/res/topbar-logo.png" /></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
         <ul class="nav navbar-nav">      
            <li><a href="/index.htm"><?php echo Start ;?></a></li>                                      
            <li><a href="/pages"><?php echo Pages ;?></a></li>  
            <li><a href="/pow-search.htm"><?php echo Search ;?></a></li>                                                                        
            <li><a href="/templates"><?php echo Templates ;?></a></li>                                                               
            <li><a href="/sysinfo"><?php echo SysInfo ;?></a></li>                         
          </ul>          
          
         <ul class="nav navbar-nav">           
            <li><a href="/sysinfo/Page Editor">Editor Help</a></li>         
            <li><a href="/pow-scan.php" title="This function will update the search function &lt;br /&gt; with the tags and description you have written" ><i class="fa fa-info-circle" ></i> <?php echo Update_Search ;?></a></li>
            <li><a href="#" id="confirm" onclick="call_popup(); return false;" title="If you have created new sub folder this &lt;br /&gt; function  will copy needed files to the folders,&lt;br /&gt; so you can edit text file in folder." ><i class="fa fa-info-circle" ></i> <?php echo System_Update ;?></a></li>
         
            <li><a href="/pow-login.php"><?php echo Logout ;?></a></li>             
            <li><a href="javascript:history.go(-1)" title="Tooltip - "><i class="fa fa-arrow-circle-left" ></i> <?php echo Back ;?></a></li>               
        </ul>          
        
        </div><!--/.nav-collapse -->
      </div>
    </nav>

<?php
if($_POST['submit_vars']) {    
$system_version_x = $_POST['system_version_x'] ;      
$language_x = $_POST['language_x'] ; 
$system_title_x = $_POST['system_title_x'] ;         
$system_tagline_x = $_POST['system_tagline_x'] ;   
$Copyright_x = $_POST['Copyright_x'] ;    
$Translator_Name_x = $_POST['Translator_Name_x'] ;     
} 
?>

<div style="display: inline; position: absolute; width:600px; left: 80px; top: 55px;">
  <h4>Translate or Customize POW CMS </h4>

  <form action="pow-custom.php" method="POST">
    <select name="language" id="language" onchange="this.form.submit()">
        <option value="">Select Language</option>
        <option value="custom">Custom</option>
        <option value="en">English</option>
        <option value="de">German</option>
        <option value="ru">Russian</option>
    </select>
</form>

    
    
    <form id="translation" class="" method="post" action="pow-custom.php">
					
		<h4>English Original - <?php echo $language_x ;?> Translation </h4>
		
		<h4>System Strings</h4>
		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> Language Code - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo $lang_code ;?>"/> 			
      <input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo lang_code ;?>"/>
		</div> 
		
		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> Language Name - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo $language ;?>"/> 			
      <input id="title" name="language_x" class="element" type="text" maxlength="255" size="35" value="<?php echo language ;?>"/>
		</div> 		
    
		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> POW CMS Translator - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo "Translator Name" ;?>"/> 			
      <input id="title" name="Translator_Name_x" class="element" type="text" maxlength="255" size="35" value="<?php echo Translator_Name ;?>"/>
		</div>
        
		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> POW CMS Version - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo $system_version ;?>"/> 			
      <input id="title" name="system_version_x" class="element" type="text" maxlength="255" size="35" value="<?php echo system_version ;?>"/>
		</div>
		
		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> POW CMS Version - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo "Version History" ;?>"/> 			
      <input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo Version_History ;?>"/>
		</div>

		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> POW CMS Version - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo "Licenses" ;?>"/> 			
      <input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo Licenses ;?>"/>
		</div>
		
           		
		<h4>Header Strings</h4>
		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> CMS Header Title - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo $system_title ;?>"/> 			
      <input id="title" name="system_title_x" class="element" type="text" maxlength="255" size="35" value="<?php echo system_title ;?>"/>
		</div> 

		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> CMS Header Tagline - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo $system_tagline ;?>"/> 			
      <input id="title" name="system_tagline_x" class="element" type="text" maxlength="255" size="35" value="<?php echo system_tagline ;?>"/>
		</div> 
		
		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> CMS Header Image - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo $system_image ;?>"/> 			
      <input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo system_image ;?>"/>
		</div> 

   	<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> CMS Top Bar Image - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo $topbar_image ;?>"/> 			
      <input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo topbar_image ;?>"/>
		</div>
     
    <h4>Page Strings</h4>		
		
    <div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> Start Page - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo "Pages" ;?>"/> 			
      <input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo Pages ;?>"/>
		</div>
    
    <div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> Start Page - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo "Links" ;?>"/> 			
      <input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo Links ;?>"/>
		</div> 		
     		
    <div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> Start Page - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo "Page Top!" ;?>"/> 			
      <input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo Page_Top ;?>"/>
		</div> 		

    <div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> Start Page - (pow-vars.js)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo "Copyright" ;?>"/> 			
      <input id="title" name="Copyright_x" class="element" type="text" maxlength="255" size="35" value="<?php echo Copyright ;?>"/>
		</div> 		


		<h4>Side Menu Strings</h4>

		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> Start Page - (side-pages.htm)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo "Start Page" ;?>"/> 			
      <input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo Start_Page ;?>"/>
		</div> 
    
		<div>
		  <label class="vars-input" for="name" title=""><i class="fa fa-info-circle" ></i> Previous Page - (side-pages.htm)</label><br>
			<input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo "Previous Page" ;?>"/> 			
      <input id="title" name="title" class="element" type="text" maxlength="255" size="35" value="<?php echo Previous_Page ;?>"/>
		</div>    		
		 <h4>Page Status Strings</h4>
	  		
	

    		
     
    <input id="saveForm" class="button" type="submit" name="submit_vars" value=" Update Translation & System Variables " />     
    
    <!-- 
     <input type="hidden" name="form_id-not" value="regex" />
     <input type="button" onclick="location.href='pow-vars.php';" value="Edit Page Variables" />
    <input id="saveForm" class="button_text" type="submit" name="submit" value="Update Page Variables" /> 
    <input type="button" onclick="location.href='pow-edit.php';" value="Edit Page" />
    -->

		</form>	
    </div>

<?php
if($_POST['submit_vars']) {
$translation_text = '<?php
define ("lang_code", "en");
define ("language", "'.$language_x.'");
define ("Translator_Name", "'.$Translator_Name_x.'"); // page variables
define ("system_title", "'.$system_title_x.'"); // page variables
define ("system_tagline", "'.$system_tagline_x.'"); // page variables
define ("system_version", "'.$system_version_x.'"); // page variables
define ("system_image", "/theme/header-image.png"); // page variables
define ("topbar_image", "/theme/topbar-logo.png"); // page variables
define ("Version_History", "Version History"); // page variables
define ("Licenses", "Licenses"); // page variables
define ("Copyright", "'.$Copyright_x.'"); // page variables

define ("Edit_Page", "Edit Page"); // index.htm
define ("Pages", "Pages"); // index.htm
define ("Links", "Links"); // index.htm
define ("Page_Top", "Page Top!"); // top menu

define ("Start_Page", "Start Page"); // side-pages,htm menu
define ("Previous_Page", "Previous Page"); // side-pages,htm menu

define ("Start", "Start"); // top menu
define ("Pages", "Pages"); // top menu
define ("Search", "Search");  // top menu
define ("Templates", "Templates"); // top menu
define ("Sysinfo", "Sysinfo"); // top menu
define ("Update_Search", "Update Search"); // top menu
define ("System_Update", "System Update"); // top menu
define ("Back", "Back"); // top menu
define ("Login", "Login"); // login pa

define ("Open_File", "Open File");   
define ("tooltip_Open_File", "Tip: HTML files must be opened in the current folder."); 
define ("Load", "Load");
define ("tooltip_Load", "Browse files in current folder. Then click load button.");
define ("View_Page", "View Page");

define ("Logout", "Logout"); // login page
define ("Username", "Username"); // login page
define ("Password", "Password"); // login page
define ("Page_Variables", "Page Variables"); // page
define ("Writing Folder File", "Writing Folder File"); // page
define ("Edit_Folder_Pages", "Folders"); // page
define ("Edit_Folder/File", "Edit Folder/File"); // page
define ("Folders", "Folders"); // page
define ("Folders", "Folders"); // page


define ("tooltip_Title", ""); // page variables
define ("tooltip_File_Name", ""); // page variables
define ("tooltip_Data_ID", ""); // page variables
define ("tooltip_Category", ""); // page variables
define ("tooltip_Date", ""); // page variables
define ("tooltip_Author", ""); // page variables
define ("tooltip_Page_Tags", ""); // page variables
define ("tooltip_Description", ""); // page variables
define ("tooltip_Image", ""); // page variables
define ("tooltip_Title", ""); // page variables 
?>';

$system_trans  = fopen("theme/translation.php", "w") or die("Unable to open file!"); 
fwrite($system_trans, pack("CCC",0xef,0xbb,0xbf));  
//fwrite($system_trans, utf8_encode($index_text));
fwrite($system_trans, $translation_text);
fclose($system_trans); 
} 

?>

<!-- - - - - - - - writing index_vars.js - - - - - - - -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - -->  

<?php

if($_POST['submit_vars']) {
$system_text = ' VARS.system_title = "'.$system_title_x.'";
 VARS.system_tagline = "'.$system_tagline_x.'";
 VARS.system_image = "/theme/header-image.png";
 VARS.copyright = "'.$Copyright_x.'";
 VARS.previous = "Previous Page";
 VARS.next = "Next Page";
 VARS.start = "Start Page";
 VARS.page_top = "Page Top!";
 VARS.title_status = "Title";       // status
 VARS.category_status = "Category"; // status
 VARS.page_status = "Page";         // status
 VARS.data_status = "Data ID";      // status
 VARS.edit = "Edit Page";           // status
 VARS.root = "Start";          // top menu
 VARS.search = "Search";       // top menu
 VARS.pages = "Pages";         // top menu
 VARS.index = "Index";         // top menu
 VARS.content = "Content";     // top menu 
 VARS.templates = "Templates"; // top menu
 VARS.sysinfo = "System Info"; // top menu
 VARS.back = "Back";           // top menu
 VARS.pages_side = "Pages";    // side menu
 VARS.links_side = "Links";    // side menu
 VARS.version_history = "Version History";              
 VARS.licenses = "Licenses";
            ' ;
        

$index_vars  = fopen("pow_vars.js", "w") or die("Unable to open file!"); 
fwrite($index_vars, pack("CCC",0xef,0xbb,0xbf));  
//fwrite($index_vars, utf8_encode($index_text));
fwrite($index_vars, $system_text);
fclose($index_vars); 

} 
?> 
 
 
 <script>
function size_it()
{
//Specifying the height of the field where the edits are done. You may have to alter the pixel-value (method: trial and error)
document.getElementById('savecontent').style.height=window.innerHeight-150+'px'
}
size_it()   
</script>

<script>
var timeleft = 5;
var downloadTimer = setInterval(function(){
  document.getElementById("progressBar").value = 10 - --timeleft;
  if(timeleft <= 0)
    clearInterval(downloadTimer);
},500);
</script>

<script type="text/javascript">
function call_popup()
{

jQuery.colorbox({width:"550px", height:"350px",html:'<div class="modal-body"><h4>Scanning Folders and Updating Files!</h4><ul><li>This will take a couple of seconds</li><li>Coyping files and updating folders</li><li>Scanning folders for Word Tags and descriptions</li><li>Writing file for Search function</li><li>Updating Search function</li><li>Writing Folder Lists Files</li><br><progress value="0" max="8" id="updateBar"></progress></ul></div>'});

            $('#cboxClose').remove();
            setTimeout(function(){
              $(window).colorbox.close();
            }, 7000)
            
$.ajax({ 
    url: "/pow-update.php",
    success: 
        function(data)
        {
           // here, for example, you load the data received from pow-update.php into
           // an html element with id #content and show an alert message
           // $("#content").html(data);
           // alert("Success")
        }
});   

var timeleft = 10;
var downloadTimer = setInterval(function(){
  document.getElementById("updateBar").value = 10 - --timeleft;
  if(timeleft <= 0)
    clearInterval(downloadTimer);
},800);       
           
}
</script>



    <!-- Bootstrap Core JavaScript -->
    <script src="/res/bootstrap/bootstrap.min.js"></script>

</body>
</html> 