    VARS = {};
    VARS.title = "Stargate Åtlantis";
    VARS.author = "admin";
    VARS.file_name = "stargate.htm";
    VARS.data = "page-stargate";
    VARS.category = "";
    VARS.date = "2017-09-15 01:25";
    VARS.image = "";
    VARS.tags = "Stargate Åtlantis";
    VARS.description = "Stargate Åtlantis is a cool science fiction television show";
                
        $.ajax({            
            url : "stargate.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});             
            