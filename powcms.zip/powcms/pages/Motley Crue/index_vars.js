﻿    VARS = {};
    VARS.title = "Mötley Crüe";
    VARS.author = "admin";
    VARS.file_name = "motley-crue.htm";
    VARS.data = "page-Mötley Crüe";
    VARS.category = "Index";
    VARS.date = "2017-09-14 17:38";
    VARS.image = "";
    VARS.tags = "Mötley Crüe Mötley_Crüe";
    VARS.description = "Mötley Crüe is a rock band. Perfect to test UTF-8 characters with their name.";
                
        $.ajax({            
            url : "motley-crue.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "/theme/side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "/theme/side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});   
            
        
    // Get Links Side menu
        $.ajax({
            url : "/theme/side-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textSideMenu").html(data); }});                         
            
    // Get Links top menu
        $.ajax({
            url : "/theme/top-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textMenuID").html(data); }});            
            
            