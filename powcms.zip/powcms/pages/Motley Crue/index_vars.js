    VARS = {};
    VARS.title = "Mötley Crüe";
    VARS.name = "Mï¿½tley Crï¿½e";
    VARS.file_name = "motley-crue.htm";
    VARS.data = "page-Mï¿½tley Crï¿½e";
    VARS.category = "Index";
    VARS.date = "";
    VARS.image = "";
    VARS.tags = "";
    VARS.description = "Mï¿½tley Crï¿½e";
                
        $.ajax({            
            url : "motley-crue.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});             
            