﻿    VARS = {};
    VARS.title = "New Page 1";
    VARS.author = "admin";
    VARS.file_name = "info.htm";
    VARS.data = "page-info";
    VARS.category = "Index";
    VARS.date = "2017-09-10 01:06";
    VARS.image = "none.png";
    VARS.tags = "Page Info Read Me";
    VARS.description = "You can create how many solders and sub folders with how many pages you want. To populate the folder you created, just click on 'Copy Folder Files' in the top menu. Then you are ready to edit edit you pages.";
                
        $.ajax({            
            url : "info.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFileID").html(data); }}); 
         
    // Get Image for page           
            $(function() {
            $("#image_load").append("<img src=none.png>"); });               
            
    // Get Folders menu
        $.ajax({
            url : "side-folders.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textFolderID").html(data); }});      

    // Get Pages menu
        $.ajax({
            url : "/theme/side-pages.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textPagesID").html(data); }});      
      
        
    // Get Links menu
        $.ajax({
            url : "/theme/side-links.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textLinksID").html(data); }});             
            
    // Get Links top menu
        $.ajax({
            url : "/theme/top-menu.htm",
            type: "GET",
            dataType: "text",
            isLocale: true,
            success: function(data) {
            $("#textMenuID").html(data); }});            
            
            