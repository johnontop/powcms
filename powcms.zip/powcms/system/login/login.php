<?php
ini_set('display_errors', '1');
/* These are our valid username and passwords */
$user = 'admin';
$pass = 'powedit';

if (isset($_POST['username']) && isset($_POST['password'])) {
    
    if (($_POST['username'] == $user) && ($_POST['password'] == $pass)) {    
        
        if (isset($_POST['rememberme'])) {
            /* Set cookie to last 1 year */
            setcookie('username', $_POST['username'], time()+60*60*24*365, '/account', 'http://localhost');
            setcookie('password', md5($_POST['password']), time()+60*60*24*365, '/account', 'http://localhost');
        
        } else {
            /* Cookie expires when browser closes */
            setcookie('username', $_POST['username'], false, '/account', 'http://localhost');
            setcookie('password', md5($_POST['password']), false, '/account', 'http://localhost');
        }
        header('Location: powedit.php');
        
    } else {
        echo 'Username/Password Invalid';
    }
    
} else {
    echo 'You must supply a username and password.';
}
?>

<html>
<head>
<title>User Login</title>
</head>
<body>
  <h2>User Login </h2>
  <form name="login" method="post" action="login.php">
   Username: <input type="text" name="username"><br>
   Password: <input type="password" name="password"><br>
   Remember Me: <input type="checkbox" name="rememberme" value="1"><br>
   <input type="submit" name="submit" value="Login!">
  </form>
</body>
</html>