<?php 
$user = 'admin';
$pass = 'password';
?>