<?php 
$user = 'admin';
$pass = 'powcms';
?>