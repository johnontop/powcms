﻿<?php 
$user = "admin"; // change username to your preference
$pass = "powcms"; // change password before upload to online server
$sqlite = "1"; // enable backup to SQLite database when saving text in Page Editor
$spellcheck = "0"; // enable browser spellchecker in TinyMCE
$tooltip = "1"; // enable tooltip in Page Editor
$ftp_host = ""; // FTP host parameter
$ftp_user = ""; // FTP user parameter
$ftp_pass = ""; // FTP password parameter
$editor = "pow-tinymce-inc.php"; // select HTML Editor
$lang_code = "en"; // Language code for translation
?>           