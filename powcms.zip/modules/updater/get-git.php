<?php 

ini_set('display_errors', '1'); 

    function collect_file($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch, CURLOPT_REFERER, "http://www.xcontest.org");
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $result = curl_exec($ch);
        curl_close($ch);
        return($result);
    }

    function write_to_file($text,$new_filename){
        $fp = fopen($new_filename, 'w');
        fwrite($fp, $text);
        fclose($fp);
    }

    // start loop here

    $path="https://raw.githubusercontent.com/johnontop/powcms/master/system/" ;
    $file="pow-edit.php" ;
    $new_file_name = "latest/".$file ;  
    $url= $path.$file ;
    echo 'Downloading from: ' .$path ;
    
    $dl_file = array("pow-version.txt","pow-edit.php", "pow-scan.php", "pow-tinymce-inc.php", "pow-custom.php", "pow-login.php", "pow-update.php", "pow-word.php", "pow-zip.php", "start.bat", "start.exe", "stop.bat", "CreateDistribution.bat", "CopyFiles.bat");
    foreach ($dl_file as $value) {
    $new_file_name = "latest/".$value ;
    write_to_file(collect_file($path.$value),$new_file_name);
    echo "<br>".$value;
    }
          
    // end loop here       

?>