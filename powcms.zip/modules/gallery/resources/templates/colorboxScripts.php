<script type="text/javascript" src="<?php echo $path; ?>"></script>

<script type="text/javascript">
    $(document).ready(function(){
        $("a[rel='colorbox']").colorbox({maxWidth: "98%", maxHeight: "98%", opacity: "0.9"});
    });
</script>