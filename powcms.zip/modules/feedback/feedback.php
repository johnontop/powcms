<?php 
ini_set('display_errors', '0');
include 'simple_html_dom.php';
// Includes database connection
$root = $_COOKIE['root']; 
//$db_file = $root.'/system/sqlite/feedback.db';  // original Db file
$table = 'data' ;
$db_file = 'feedback.db';
$db_backup = 'feedback_backup.db';

/* check db file size with backup to prevent over writing file with empty file */
$filesize_db = filesize($db_file );
$filesize_db_backup = filesize($db_backup);
if ($filesize_db < $filesize_db_backup) {
    copy($db_backup,$db_file);   
}

$db = new SQLite3($db_file);
   if(!$db) {
      echo $db -> lastErrorMsg();
   } else {
      $description = "Opened SQLite database";
   }  

if(isset($_GET['type'])) {
$type = $_GET['type'] ;
setcookie('type', $type , time()+5 );
header('Location: index.htm');
} 

if(isset($_GET['user'])) {
$user = $_GET['user'] ;
setcookie('user', $user , time()+5 );
header('Location: index.htm');
} 

if(isset($_GET['hide'])) {
$id = $_GET['hide'] ;
$query = "UPDATE $table SET hide='1' WHERE id='$id' " ;
	if( $db->exec($query) ){
	 setcookie('description', 'Data is updated successfully.' , time()+60 );
	}else{
	 setcookie('description', 'Sorry, Data is not updated.' , time()+60 );		
	}
header('Location: index.htm');
}
   
if(isset($_COOKIE['description'])) {
$description = $_COOKIE['description'] ;
}  
// Makes query with row id
$query = "SELECT id, * FROM $table WHERE hide='0' ORDER BY date_added DESC LIMIT 50";

if(isset($_COOKIE['type'])) {
$show_description = $_COOKIE['type'] ;
$query = "SELECT id, * FROM $table WHERE category = '$show_description' AND hide='0' ORDER BY date_added DESC LIMIT 50";
} 

if(isset($_COOKIE['user'])) {
$user = $_COOKIE['user'] ;
$query = "SELECT id, * FROM $table WHERE name = '$user' AND hide='0' ORDER BY date_added DESC LIMIT 50";
}  
 
// Run the query and set query result in $result
$result = $db->query($query);   

if($_POST['submit_insert']) { 
$ip_address = $_SERVER['REMOTE_ADDR'];
$date = $_POST['date_added'] ;   
$name = $_POST['name'] ;      
$email = $_POST['email'] ;
$web_site = $_POST['web_site'] ;
$country = $_POST['country'] ; 
$category = $_POST['category'] ;
$title = $_POST['title'] ; 
$description = $_POST['description'] ;         
$newsletter = $_POST['newsletter'] ; 
$country_code = $_POST['country_code'] ;
$country = $_POST['country'] ;   
$date = date("Y-m-d H:i") ;
  
	// Makes query with post data
$query = "INSERT INTO $table (date_added, ip_address, name, email, web_site, country, category, title, description, newsletter, country_code, country ) VALUES ('$date', '$ip_address', '$name', '$email', '$web_site', '$country', '$category', '$title', '$description', '$newsletter', '$country_code', '$country' )";
	// Executes the query
	// If data inserted then set success description otherwise set error description
	// Here $db comes from "db_connection.php"
	if( $db->exec($query) ){
		$description = "Data is inserted into <a href='/system/sqlite/phpliteadmin.php?table=pages&action=row_view' target='_blank' >SQLite</a>";
		setcookie('description', 'Thank you for your feedback.<br>It was inserted into the SQLite db' , time()+60 );
		// make a backup copy of db  
       copy($db_file,$db_backup);      
    /*   if(!copy($db_file,$db_backup))
       {echo "Failed to copy ". $db_file."<br>";}
         else
       {echo
       "Copied ".$db_file." into ".$db_backup."<br>";
      }   */ 
		header('Location: index.htm');
	}else{
		$description = "Sorry, Data is not inserted into <a href='/system/sqlite/phpliteadmin.php?table=pages&action=row_view' target='_blank' >SQLite</a>";
		setcookie('description', 'Sorry, your feedback was not inserted into the SQLite db' , time()+60 );
		header('Location: index.php');
	}
 } // end sqlite insert	

 
?>
<style>
.title {
 font-weight:600;
 color: #3399ff;
 }
</style>
<div id="faqs">
<h6><i class="fa fa-info-circle "></i> Feedback Module - read more  ...</h6>
<div>

<p>This is a HTML-PHP Hybrid "Module" PHP script that can be edited with TinyMCE Editor. This is how it works.</p>
<ul>
<li>index.htm reads the index_vars.js and loads the TinyMCE editable PHP/HTML page feedback.php.</li>
<li>Feedback.php reads and inserts submitted data in SQLite db feedback.db</li>
<li>The SQLite db feedback.db is copied/backuped to feedback_backup.db </li>
<li>If feedback.db size is less than feedback_backup.db the backup is restored (to preserv db data when updating an online site) </li>
<li>jQuery Validate is used to validate input fields before submit.</li>
<li>User info descriptions are stored in a cookie for 60 seconds and showed as a status description.</li>
<li>You can edit/translate this script with the Page Editor</li>
<li>Date/Time stamp and IP-address is also inserted.</li>
<li>This Module with PHP/SQLite Db will be improved as a demo create/insert script.</li>
<li>You can modify this Module to you liking and move the folder to any place and it will still work.</li>
</ul>
</div>
</div>  <!-- end faqs -->

<?php
if(!isset($_COOKIE['type'])) {
?>
                        
<form id="feedbackForm" class="" action="feedback.php" method="post">
<table class="table table-no-border" border="0" width="20%" cellspacing="2" cellpadding="2">
<tbody>
<tr>
<td>Status:</td>
<td><span style="color:green;"><?php echo $description ;?></span></td>
</tr>
<tr>
<td>Name: (required)</td>
<td><input name="name" size="35" type="text" value="" /></td>
</tr>
<tr>
<td>Email: (required)</td>
<td><input name="email" size="35" type="text" /></td>
</tr>
<tr>
<td>Web Site: (http://example.com)</td>
<td><input name="web_site" size="35" type="text" value="" /></td>
</tr>
<tr>
<td>Country:</td>
<td>
<select id="country" name="country" widht="150px">
<option value="Undefined">Select Country</option>
<option value="Afghanistan">Afghanistan</option>
<option value="Åland Islands">Åland Islands</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="American Samoa">American Samoa</option>
<option value="Andorra">Andorra</option>
<option value="Angola">Angola</option>
<option value="Anguilla">Anguilla</option>
<option value="Antarctica">Antarctica</option>
<option value="Antigua and Barbuda">Antigua and Barbuda</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Aruba">Aruba</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Bangladesh">Bangladesh</option>
<option value="Barbados">Barbados</option>
<option value="Belarus">Belarus</option>
<option value="Belgium">Belgium</option>
<option value="Belize">Belize</option>
<option value="Benin">Benin</option>
<option value="Bermuda">Bermuda</option>
<option value="Bhutan">Bhutan</option>
<option value="Bolivia">Bolivia</option>
<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
<option value="Botswana">Botswana</option>
<option value="Bouvet Island">Bouvet Island</option>
<option value="Brazil">Brazil</option>
<option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
<option value="Brunei Darussalam">Brunei Darussalam</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Burkina Faso">Burkina Faso</option>
<option value="Burundi">Burundi</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Canada">Canada</option>
<option value="Cape Verde">Cape Verde</option>
<option value="Cayman Islands">Cayman Islands</option>
<option value="Central African Republic">Central African Republic</option>
<option value="Chad">Chad</option>
<option value="Chile">Chile</option>
<option value="China">China</option>
<option value="Christmas Island">Christmas Island</option>
<option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
<option value="Colombia">Colombia</option>
<option value="Comoros">Comoros</option>
<option value="Congo">Congo</option>
<option value="Congo, Democratic Republic">Congo, Democratic Republic</option>
<option value="Cook Islands">Cook Islands</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Cote D'ivoire">Cote D'ivoire</option>
<option value="Croatia">Croatia</option>
<option value="Cuba">Cuba</option>
<option value="Cyprus">Cyprus</option>
<option value="Czechia">Czechia</option>
<option value="Denmark">Denmark</option>
<option value="Djibouti">Djibouti</option>
<option value="Dominica">Dominica</option>
<option value="Dominican Republic">Dominican Republic</option>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Equatorial Guinea">Equatorial Guinea</option>
<option value="Eritrea">Eritrea</option>
<option value="Estonia">Estonia</option>
<option value="Ethiopia">Ethiopia</option>
<option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
<option value="Faroe Islands">Faroe Islands</option>
<option value="Fiji">Fiji</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<option value="French Guiana">French Guiana</option>
<option value="French Polynesia">French Polynesia</option>
<option value="French Southern Territories">French Southern Territories</option>
<option value="Gabon">Gabon</option>
<option value="Gambia">Gambia</option>
<option value="Georgia">Georgia</option>
<option value="Germany">Germany</option>
<option value="Ghana">Ghana</option>
<option value="Gibraltar">Gibraltar</option>
<option value="Greece">Greece</option>
<option value="Greenland">Greenland</option>
<option value="Grenada">Grenada</option>
<option value="Guadeloupe">Guadeloupe</option>
<option value="Guam">Guam</option>
<option value="Guatemala">Guatemala</option>
<option value="Guernsey">Guernsey</option>
<option value="Guinea">Guinea</option>
<option value="Guinea-bissau">Guinea-bissau</option>
<option value="Guyana">Guyana</option>
<option value="Haiti">Haiti</option>
<option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
<option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
<option value="Honduras">Honduras</option>
<option value="Hong Kong">Hong Kong</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="India">India</option>
<option value="Indonesia">Indonesia</option>
<option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
<option value="Iraq">Iraq</option>
<option value="Ireland">Ireland</option>
<option value="Isle of Man">Isle of Man</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Jersey">Jersey</option>
<option value="Jordan">Jordan</option>
<option value="Kazakhstan">Kazakhstan</option>
<option value="Kenya">Kenya</option>
<option value="Kiribati">Kiribati</option>
<option value="Korea, North">Korea, North</option>
<option value="Korea, Republic of">Korea, Republic of</option>
<option value="Kuwait">Kuwait</option>
<option value="Kyrgyzstan">Kyrgyzstan</option>
<option value="Lao">Lao</option>
<option value="Latvia">Latvia</option>
<option value="Lebanon">Lebanon</option>
<option value="Lesotho">Lesotho</option>
<option value="Liberia">Liberia</option>
<option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Macao">Macao</option>
<option value="Macedonia">Macedonia</option>
<option value="Madagascar">Madagascar</option>
<option value="Malawi">Malawi</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Marshall Islands">Marshall Islands</option>
<option value="Martinique">Martinique</option>
<option value="Mauritania">Mauritania</option>
<option value="Mauritius">Mauritius</option>
<option value="Mayotte">Mayotte</option>
<option value="Mexico">Mexico</option>
<option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
<option value="Moldova, Republic of">Moldova, Republic of</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Montenegro">Montenegro</option>
<option value="Montserrat">Montserrat</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Myanmar">Myanmar</option>
<option value="Namibia">Namibia</option>
<option value="Nauru">Nauru</option>
<option value="Nepal">Nepal</option>
<option value="Netherlands">Netherlands</option>
<option value="Netherlands Antilles">Netherlands Antilles</option>
<option value="New Caledonia">New Caledonia</option>
<option value="New Zealand">New Zealand</option>
<option value="Nicaragua">Nicaragua</option>
<option value="Niger">Niger</option>
<option value="Nigeria">Nigeria</option>
<option value="Niue">Niue</option>
<option value="Norfolk Island">Norfolk Island</option>
<option value="Northern Mariana Islands">Northern Mariana Islands</option>
<option value="Norway">Norway</option>
<option value="Oman">Oman</option>
<option value="Pakistan">Pakistan</option>
<option value="Palau">Palau</option>
<option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
<option value="Panama">Panama</option>
<option value="Papua New Guinea">Papua New Guinea</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Philippines">Philippines</option>
<option value="Pitcairn">Pitcairn</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Puerto Rico">Puerto Rico</option>
<option value="Qatar">Qatar</option>
<option value="Reunion">Reunion</option>
<option value="Romania">Romania</option>
<option value="Russian Federation">Russian Federation</option>
<option value="Rwanda">Rwanda</option>
<option value="Saint Helena">Saint Helena</option>
<option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
<option value="Saint Lucia">Saint Lucia</option>
<option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
<option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
<option value="Samoa">Samoa</option>
<option value="San Marino">San Marino</option>
<option value="Sao Tome and Principe">Sao Tome and Principe</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Serbia">Serbia</option>
<option value="Seychelles">Seychelles</option>
<option value="Sierra Leone">Sierra Leone</option>
<option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="Solomon Islands">Solomon Islands</option>
<option value="Somalia">Somalia</option>
<option value="South Africa">South Africa</option>
<option value="South Georgia and The South Sandwich Islands">South Georgia and Sandwich Islands</option>
<option value="Spain">Spain</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="Sudan">Sudan</option>
<option value="Suriname">Suriname</option>
<option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
<option value="Swaziland">Swaziland</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syrian Arab Republic">Syrian Arab Republic</option>
<option value="Taiwan, Province of China">Taiwan, Province of China</option>
<option value="Tajikistan">Tajikistan</option>
<option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
<option value="Thailand">Thailand</option>
<option value="Timor-leste">Timor-leste</option>
<option value="Togo">Togo</option>
<option value="Tokelau">Tokelau</option>
<option value="Tonga">Tonga</option>
<option value="Trinidad and Tobago">Trinidad and Tobago</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Turkmenistan">Turkmenistan</option>
<option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
<option value="Tuvalu">Tuvalu</option>
<option value="Uganda">Uganda</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Emirates">United Arab Emirates</option>
<option value="United Kingdom">United Kingdom</option>
<option value="United States">United States</option>
<option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
<option value="Uruguay">Uruguay</option>
<option value="Uzbekistan">Uzbekistan</option>
<option value="Vanuatu">Vanuatu</option>
<option value="Venezuela">Venezuela</option>
<option value="Viet Nam">Viet Nam</option>
<option value="Virgin Islands, British">Virgin Islands, British</option>
<option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
<option value="Wallis and Futuna">Wallis and Futuna</option>
<option value="Western Sahara">Western Sahara</option>
<option value="Yemen">Yemen</option>
<option value="Zambia">Zambia</option>
<option value="Zimbabwe">Zimbabwe</option>
</select></td>
</tr>
<tr>
<td>Message type:</td>
<td><select name="category">
<option value="Undefined">Select Message Type</option>
<option value="Comment">Comment</option>
<option value="Suggestion">Suggestion</option>
<option value="Bug">Bug Report</option>
<option value="Website">Web Site/Link</option>
<option value="Contact">Contact</option>
<option value="Testimonial">Testimonial</option>
</select></td>
</tr>
<tr>
<td>Title/Subject: (required)</td>
<td><input name="title" size="35" type="text" value="" /></td>
</tr>
<tr>
<td>Message:</td>
<td><textarea cols="32" name="description" rows="4"></textarea></td>
</tr>
<tr>
<td>Subscribe to Newsletter:</td>
<td><input name="newsletter" size="35" type="checkbox" /> <a href="terms.htm" class="iframe text-muted small text-center" > Terms (If feature is ever implemented :-)</a></td>
</tr>
<tr>
<td>What is: 7 + 4 =</td>
<td><input name="captcha" size="5" type="text" /></td>
</tr>
<tr>
<td></td>
<td><input class="button" name="submit_insert" type="submit" value="Send Feedback description" /></td>
</tr>
</tbody>
</table>
</form>
<?php
} // end if not set cookie type
?>

<hr />
<div style="margin: 20px auto;">
<h2>Feedback descriptions</h2>
View Feedback type:
  <a href="feedback.php?type=Undefined" ><span class="small">Undefined</span></a>
 | <a href="feedback.php?type=Suggestion" ><span class="small">Suggestions</span></a>  
 | <a href="feedback.php?type=Comment" ><span class="small">Comments</span></a>
 | <a href="feedback.php?type=Bugs" ><span class="small">Bugs</span></a>
 | <a href="feedback.php?type=Contact" ><span class="small">Contact</span></a>
 | <a href="feedback.php?type=Testimonial" ><span class="small">Testimonials</span></a> 
 | <a href="feedback.php?type=Website" ><span class="small">Website Links</span></a>
 | <a href="#" onclick="pageReload(); return false;"><span class="small">All</span></a>
<table class="table" border="0" width="90%" cellspacing="1" cellpadding="5">
<tbody>
<tr>
<td width="15%"><strong>Name</strong></td>
<td width="50%"><strong>Feedback</strong></td>
<td width="10%"><strong>Type/Action</strong></td>
</tr>
<?php while($row = $result->fetchArray()) {?>
<tr>
<td><a href="feedback.php?user=<?php echo $row['name'];?>" ><div class="title"><?php echo $row['name'];?></div></a>                        
<div class="small"><?php echo substr($row['date_added'], 0, 10);?></div>
<div class="small"><?php echo $row['country'];?></div>
</td>
<td><span class="title"><?php echo $row['title'];?></span>
<div><?php echo $row['description'];?></div>                                                                                                
<?php 
$url = $row['web_site'];
$s2icon = 'https://www.google.com/s2/u/0/favicons?domain='.$url;
echo "<img src='$s2icon'>";
?>
<span class="small"><a href="<?php echo $row['web_site'];?>" target="_blank"> <?php echo $row['web_site'];?></a></span>
</td>
<td>
<a href="feedback.php?type=<?php echo $row['category'];?>" ><span class="small"><?php echo $row['category'];?></span></a>

<?php if(isset($_COOKIE['login_status']) && $_COOKIE['login_status']== 'Logged In' ) { ?>
<br><span class="small title">ID:<?php echo $row['id'];?> </span><a href="feedback.php?hide=<?php echo $row['id'];?>" ><span class="small">Hide</span></a>
 | <a href="phpliteadmin.php?table=<?php echo $table ;?>&action=row_editordelete&pk=[<?php echo $row['id'] ?>]&type=edit" target="_blank"><span class="small">Edit</span></a>
<?php } else {  ?>  <i class="fa fa-info-circle title" title="Sort by description type - Login to Edit or Hide"><?php }  ?>
</td>
</tr>
<?php } ?></tbody>
</table>
</div>


<?php 

?>

<script src="/res/js/jquery.validate.min.js"></script>
<script>
$(document).ready(function () {

    $('#feedbackForm').validate({ // initialize the plugin
        rules: {

            name: {
                required: true,
                minlength: 3
            },
            email: {
                required: true,
                email: true
            },            
            title: {
                required: true,
                minlength: 6
            },            
           captcha: {
                required: true,
                number: true,
                min: 11,
                max: 11,
            }            
        }
    });

});
</script> 
<script>
// https://davidwalsh.name/jquery-sliders
$(document).ready(function() {
	$('#faqs h6').each(function() {
		var tis = $(this), state = false, answer = tis.next('div').hide().css('height','auto').slideUp();
		tis.click(function() {
			state = !state;
			answer.slideToggle(state);
			tis.toggleClass('active',state);
		});
	});
});

$(document).ready(function() {
	$('#read-more h6').each(function() {
		var tisrm = $(this), state = false, answer = tisrm.next('div').hide().css('height','auto').slideUp();
		tisrm.click(function() {
			state = !state;
			answer.slideToggle(state);
			tisrm.toggleClass('active',state);
		});
	});
});
</script>   

<script>
function pageReload() {
    location.reload();
}
</script>

		<script>
			$(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements
				$(".group1").colorbox({rel:'group1'});
				$(".group2").colorbox({rel:'group2', transition:"fade"});
				$(".group3").colorbox({rel:'group3', transition:"none", width:"75%", height:"75%"});
				$(".group4").colorbox({rel:'group4', slideshow:true});
				$(".ajax").colorbox();
				$(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390});
				$(".vimeo").colorbox({iframe:true, innerWidth:500, innerHeight:409});
				$(".iframe").colorbox({iframe:true, width:"70%", height:"90%"});
				$(".inline").colorbox({inline:true, width:"50%"});
				$(".callbacks").colorbox({
					onOpen:function(){ alert('onOpen: colorbox is about to open'); },
					onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
					onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
					onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
					onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
				});

				$('.non-retina').colorbox({rel:'group5', transition:'none'})
				$('.retina').colorbox({rel:'group5', transition:'none', retinaImage:true, retinaUrl:true});
				
				//Example of preserving a JavaScript event for inline calls.
				$("#click").click(function(){ 
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this description will still be here.");
					return false;
				});
			});
		</script>   