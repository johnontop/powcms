<?php
function getFavicon($url) {

   $check = parse_url($url);
   
   if(empty($check['scheme'])) {   // check if there http whatever, if not add it.
    $url = 'http://' . ltrim($url, '/');       
    }
    
   $check = parse_url($url);  
   if (!empty($check['host'])) { // Get host path (thats all we need , get rid of path)  check if smth is there
       $url = $check['host'];
       $url = $check['scheme'] . '://' . $url; // put back original scheme
       }
    else {
        return false;
    }
   
    $href = false;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,2); 
    curl_setopt($ch, CURLOPT_TIMEOUT, 2); //timeout in seconds   
    $content = curl_exec($ch);
    if (!empty($content)) {
      $dom = new DOMDocument();
      @$dom->loadHTML($content); //supress errors
      $items = $dom->getElementsByTagName('link');
      foreach ($items as $item) {
         $rel = $item->getAttribute('rel');
         if ($rel == 'icon' or $rel == 'shortcut icon') {
            $href = $item->getAttribute('href');
            break;
         }
      }
   }
   if ($href != false) {
    $href = parse_url($href);
    return $url . $href['path'];
    }
return false;
} 


    function get_links($url) {

        // Create a new DOM Document to hold our webpage structure
        $xml = new DOMDocument();

        // Load the url's contents into the DOM

        $xml->loadHTMLFile($url);

        // Empty array to hold all links to return
        $links = array();

        //Loop through each <a> tag in the dom and add it to the link array
        foreach ($xml->getElementsByTagName('a') as $link) {
            $url = $link->getAttribute('href');
            if (!empty($url)) {
                $links[] = $link->getAttribute('href');
            }
        }

        //Return the links
        return $links;
    }
    
function getFavicons($url){
    # make the URL simpler
    $elems = parse_url($url);
    $url = $elems['scheme'].'://'.$elems['host'];

    # load site
    $output = file_get_contents($url);

    # look for the shortcut icon inside the loaded page
    $regex_pattern = "/rel=\"shortcut icon\" (?:href=[\'\"]([^\'\"]+)[\'\"])?/";
    preg_match_all($regex_pattern, $output, $matches);

    if(isset($matches[1][0])){
        $favicon = $matches[1][0];

        # check if absolute url or relative path
        $favicon_elems = parse_url($favicon);

        # if relative
        if(!isset($favicon_elems['host'])){
            $favicon = $url . '/' . $favicon;
        }

        return $favicon;
    }

    return false;
}    
    
$website = "https://www.aftonbladet.se";
//$favicon = getfavicon($website);
$favicon = getFavicon($website);

echo 'Links: '.$get_links = get_links($website);
echo '<br>';
echo 'Icon: '.$favicon;
?>