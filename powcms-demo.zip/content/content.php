﻿<?php
ini_set('display_errors', '1');

if (!isset($_GET['action'])){ 
  echo "Collecting update information.<br />";
}  else {
  echo "GET is set to - files!<br />";  
  $updatefiles = "pow-download.bat";
  exec("start /MIN $updatefiles");
  echo "Finished Backup";
  
    function collect_file($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch, CURLOPT_REFERER, "http://www.xcontest.org");
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $result = curl_exec($ch);
        curl_close($ch);
        return($result);
    }

    function write_to_file($text,$new_filename){
        $fp = fopen($new_filename, 'w');
        fwrite($fp, $text);
        fclose($fp);
    }

    // start loop here

    $path="https://raw.githubusercontent.com/johnontop/powcms/master/system/" ;
   // $file="pow-edit.php" ;
   // $new_file_name = "latest/".$file ;  
   // $url= $path.$file ;
   // echo 'Downloading from: ' .$path ;
    
    $dl_file = array("pow-version.txt","pow-edit.php", "pow-scan.php", "pow-tinymce-inc.php", "pow-custom.php", "pow-login.php", "pow-update.php", "pow-word.php", "pow-zip.php", "start.bat", "start.exe", "stop.bat", "CreateDistribution.bat", "CopyFiles.bat");
    foreach ($dl_file as $value) {
    $new_file_name = "latest/".$value ;
    write_to_file(collect_file($path.$value),$new_file_name);
    echo "<br>".$value;
    usleep(500000);
    }  
    //$powcms="https://github.com/johnontop/powcms/blob/master/powcms.zip?raw=true" ;
    //write_to_file(collect_file($powcms),"latest/pow-cms.zip");
    
    $message = "Manually copy updated files in /updater/latest/ folder to your root folder" ;
    setcookie('message', $message , time()+60 );    
  header('Location: index.htm');
exit;  
}

$online_history = file_get_contents('https://raw.githubusercontent.com/johnontop/powcms/master/system/history.htm');
  $dl_filename = 'latest/history.htm';
  $fp = fopen($dl_filename, 'w');
  fwrite($fp, $online_history);
  fclose($fp);

echo "<h4>Updater detects your ..</h4>" ;
$local_version = file_get_contents('../pow-version.txt');
echo "Local version to: <b>" ;
echo $local_version .'</b><br>';
$downloaded_version = file_get_contents('latest/pow-version.txt');
echo "Downloaded version to: <b>" ;
echo $downloaded_version .'</b><br>';   
//$online_version = file_get_contents('https://powcms.000webhostapp.com/pow-version.txt');
$online_version = file_get_contents('https://raw.githubusercontent.com/johnontop/powcms/master/system/pow-version.txt');
echo "Online version is: <b>" ;
echo $online_version .'</b><br><br>';
if ($local_version == $online_version){
echo "<strong>You have the latest version - Your good</strong><br>" ;
} else   {
$message = "There is a new version for download - Consider updating system files" ;
if(isset($_COOKIE['message'])) {
$message = $_COOKIE['message'] ;
} 
echo "<strong>" .$message. "</strong><br>" ;
} 
if ($local_version != $online_version){   ?>
<h4 id="finalMessage"></h4>
<progress id="progressBar" value="0" max="100" style="width: 300px;"></progress> <span id="status"></span> <br /> <a class="button" href="updater.php?action=1" onclick="start(0);"> Download and Update System Files </a>
<p><br />POW CMS Updater will download the latest POW CMS system files from GitHub system folder.<br /> The files will be saved to the folder /updater/latest. Read latest version history below.</p>
<br /> <iframe src="latest/history.htm" width="100%" height="300px"></iframe> <?php
}
?>
<script>
function start(al) {
 // document.getElementById('progressBar').style.display='block';
  var bar = document.getElementById('progressBar');
  var status = document.getElementById('status');
  status.innerHTML = al+"%";
  var finalMessage = document.getElementById('finalMessage');
  finalMessage.innerHTML = "Backup files and download updates";
  bar.value = al;
  al++;
    var sim = setTimeout("start("+al+")",80);
    if(al == 100){
      status.innerHTML = "100%";
      bar.value = 100;
      clearTimeout(sim);
      var finalMessage = document.getElementById('finalMessage');
      finalMessage.innerHTML = "Download of updates is complete";
        }
    }
</script>