 
<?php 
ini_set('display_errors', '0');

echo $_POST['submit'];

if($_POST['submit']) {

  $file = 'index.html'; 
  $newfile = '../../../index.htm';
  if(!copy($file,$newfile))
   {echo "Failed to copy ". $file."<br>";}
   else
    {echo
     "Copied ".$file." into ".$newfile."<br>";
    } 
    
  $file = 'pow_vars.js'; 
  $newfile = '../../../pow_vars.js';
  if(!copy($file,$newfile))
   {echo "Failed to copy ". $file."<br>";}
   else
    {echo
     "Copied ".$file." into ".$newfile."<br>";
    }     
    
  $file = 'default-mod.css'; 
  $newfile = '../../../theme/default-mod.css';
  if(!copy($file,$newfile))
   {echo "Failed to copy ". $file."<br>";}
   else
    {echo
     "Copied ".$file." into ".$newfile."<br>";
    }     

$srcPath = './theme/';
$destPath = '../../../theme/';  
$srcDir = opendir($srcPath);
while($readFile = readdir($srcDir))
{
    if($readFile != '.' && $readFile != '..')
    {
        /* this check doesn't really make sense to me,
           you might want !file_exists($destPath . $readFile) */
        if (!file_exists($readFile)) 
        {
            if(copy($srcPath . $readFile, $destPath . $readFile))
            {
                echo "Copy file: ".$readFile."<br>" ;
            }
            else
            {
                echo "Canot Copy file";
            }
        }
    }
}
closedir($srcDir);

header('Location: http://localhost/index.htm');

} 
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Start Page Theme</title>
<style>
.button {     /* https://catalin.red/just-another-awesome-css3-buttons/ */   
    display: inline-block;
    white-space: nowrap;
    background-color: #ddd;
    background-image: -webkit-gradient(linear, left top, left bottom, from(#eee), to(#ccc));
    background-image: -webkit-linear-gradient(top, #eee, #ccc);
    background-image: -moz-linear-gradient(top, #f3f3f3, #ddd);
    background-image: -ms-linear-gradient(top, #eee, #ccc);
    background-image: -o-linear-gradient(top, #eee, #ccc);
     background-image: linear-gradient(top, #f3f3f3, #ddd);
            
    border: 1px solid #777;
    padding-top: 3px;
    padding-right: 28px;
    padding-bottom: 5px;
    padding-left: 28px;
    margin: 0.2em;
    font: Roboto, Arial, Helvetica;
    font-size: 16px;
    font-weight:400;
    text-decoration: none;
    color: #222;
    text-shadow: 0 1px 0 rgba(255,255,255,.8);
    border-radius: 2px;
    box-shadow: 0 0 1px 1px rgba(255,255,255,.8) inset, 0 1px 0 rgba(0,0,0,.3);
}
</style>

</head>
<body>  
<div class="container">
<br>
<div style="absolute:relative; left:30; top:80; z-index:1000;">
<form id="myForm" class="" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
<input id="saveForm" class="button" name="submit" type="submit" value="Apply Page Design" />
</form>	
<br>
<?php
$get_file  = file_get_contents("index.html");
echo $get_file ;
?>

</div>

</div>
</body>
</html>




