<?php
define ("lang_code", "en");
define ("language", "English");
define ("language_status", "English Translation Loaded");
define ("Translator_Name", "Admin Developer"); // optional

define ("system_title", "Portable Offline Web CMS"); // page variables
define ("system_tagline", "Rocks the world!"); // page variables
define ("system_version", "v0.12"); // page variables
define ("system_image", "/theme/header-image.png"); // page variables
define ("topbar_image", "/theme/topbar-logo.png"); // page variables
define ("Copyright", "Portable Offline Web CMS 2017"); // page variables

define ("Version_History", "Version History"); // page variables
define ("Licenses", "Licenses"); // page variables

define ("Edit_Page", "Edit Page"); // index.htm
define ("Pages", "Pages"); // index.htm
define ("Links", "Links"); // index.htm
define ("Page_Top", "Page Top!"); // top menu

define ("Start_Page", "Start Page"); // side-pages,htm menu
define ("Previous_Page", "Previous Page"); // side-pages,htm menu

define ("Start", "Start"); // top menu
define ("Pages", "Pages"); // top menu
define ("Search", "Search");  // top menu
define ("Templates", "Templates"); // top menu
define ("Sysinfo", "Sysinfo"); // top menu
define ("Update_Search", "Update Search"); // top menu
define ("System_Update", "System Update"); // top menu
define ("Back", "Back"); // top menu
define ("Login", "Login"); // login pa

define ("Open_File", "Open File");   
define ("tooltip_Open_File", "Tip: HTML files must be opened in the current folder."); 
define ("Load", "Load");
define ("tooltip_Load", "Browse files in current folder. Then click load button.");
define ("View_Page", "View Page");

define ("Logout", "Logout"); // login page
define ("Username", "Username"); // login page
define ("Password", "Password"); // login page
define ("Page_Variables", "Page Variables"); // page
define ("Writing Folder File", "Writing Folder File"); // page
define ("Edit_Folder_Pages", "Folders"); // page
define ("Edit_Folder/File", "Edit Folder/File"); // page
define ("Folders", "Folders"); // page
define ("Folders", "Folders"); // page


define ("tooltip_Title", ""); // page variables
define ("tooltip_File_Name", ""); // page variables
define ("tooltip_Data_ID", ""); // page variables
define ("tooltip_Category", ""); // page variables
define ("tooltip_Date", ""); // page variables
define ("tooltip_Author", ""); // page variables
define ("tooltip_Page_Tags", ""); // page variables
define ("tooltip_Description", ""); // page variables
define ("tooltip_Image", ""); // page variables
define ("tooltip_Title", ""); // page variables 
?>