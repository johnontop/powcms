<html>
<head>
<title>PHP Info</title>
<body>
</body>
</html>

<?php
ini_set('display_errors', '1'); 
ini_set('default_charset', 'UTF-8');

$root = $_COOKIE['root'];  

$db_file = $root.'/system/sqlite/powcms.db';
$db = new SQLite3($db_file);
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      echo "Opened SQLite database successfully\n";
   }

echo '<h3>Test of connecting to database</h3>';
//echo gethostname(); // may output e.g,: sandie

/*
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('/system/sqlite/powcms.db');
      }
   }
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      echo "Opened SQLite database successfully\n";
   }

*/
echo phpinfo();


?>