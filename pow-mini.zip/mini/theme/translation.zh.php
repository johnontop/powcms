<?php
// Copy & paste translation strings from translation.en.php
define ("lang_code", "zh");
define ("language", "Chinese");
define ("language_status", "No translation yet");
define ("Translator_Name", ""); // optional

?>