<?php
// Copy & paste translation strings from translation.en.php
define ("lang_code", "sv");
define ("language", "Swedish");
define ("language_status", "No translation yet");
define ("Translator_Name", ""); // optional

?>