<?php
// Copy & paste translation strings from translation.en.php
define ("lang_code", "fr");
define ("language", "French");
define ("language_status", "No translation yet");
define ("Translator_Name", ""); // optional

?>